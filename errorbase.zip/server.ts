import express from "express";
import http from "http";
import path from "path";
import { createServer as createViteServer } from "vite";
import { Database } from "./server/db.ts";
import { authRouter } from "./server/auth.ts";
import { restRouter } from "./server/rest.ts";
import { storageRouter } from "./server/storage.ts";
import { realtimeServer } from "./server/realtime.ts";

const app = express();
const PORT = 3000;

// 1. CORS Configuration Middleware
app.use((req, res, next) => {
  const origin = req.headers.origin || "*";
  res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With, Range");
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Expose-Headers", "Content-Range, Content-Length, ETags");
  
  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }
  next();
});

// 2. Custom Cookie Parser (No external library requirement)
app.use((req: any, res, next) => {
  req.cookies = {};
  const cookieHeader = req.headers.cookie;
  if (cookieHeader) {
    const list = cookieHeader.split(";");
    for (const item of list) {
      const parts = item.split("=");
      if (parts.length >= 2) {
        const key = parts[0].trim();
        const val = parts.slice(1).join("=").trim();
        req.cookies[key] = decodeURIComponent(val);
      }
    }
  }
  next();
});

// 3. Request Parsers
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// 4. Winston-like DB API Logger Middleware
app.use((req, res, next) => {
  const startTime = Date.now();
  const originalEnd = res.end;

  res.end = function(chunk?: any, encoding?: any, cb?: any) {
    const durationMs = Date.now() - startTime;
    const ip = (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress || "127.0.0.1";
    
    // Ignore static files/assets logs to prevent dashboard spam
    const pathName = req.originalUrl || req.url;
    if (
      !pathName.startsWith("/@vite") &&
      !pathName.startsWith("/src") &&
      !pathName.startsWith("/node_modules") &&
      !pathName.endsWith(".css") &&
      !pathName.endsWith(".js") &&
      !pathName.endsWith(".png") &&
      !pathName.endsWith(".ico") &&
      pathName !== "/"
    ) {
      Database.addLog({
        method: req.method,
        path: pathName,
        status: res.statusCode,
        ip,
        durationMs,
      });
    }

    return originalEnd.call(this, chunk, encoding, cb);
  } as any;

  next();
});

// --- API Routes Setup ---

// Healthcheck Router
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "healthy",
    platform: "ErrorBase System v1",
    uptimeSeconds: process.uptime(),
    metrics: {
      tables: Database.getTables().length,
      users: Database.getUsers().length,
      buckets: Database.getBuckets().length,
    }
  });
});

// Mount specialized routers
app.use("/auth", authRouter);
app.use("/api/rest", restRouter);
app.use("/storage", storageRouter);

// Database debug hooks for direct SQL from dashboard
app.post("/api/sql/execute", (req, res) => {
  const { query } = req.body;
  if (!query) {
    return res.status(400).json({ success: false, error: "Empty query string provided." });
  }

  const result = Database.executeSql(query);
  res.status(result.success ? 200 : 400).json(result);
});

// Configure Vite integration for SPA Client or Static Server
async function bootstrap() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode: Mount Vite as middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development server linked successfully.");
  } else {
    // Production Mode: static static assets from `dist` folder
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving static production client under dist/");
  }

  // Create HTTP server to attach socket listeners
  const server = http.createServer(app);

  // Initialize Realtime subscription socket engine
  realtimeServer.init(server);

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`ErrorBase server listening on http://0.0.0.0:${PORT}`);
  });
}

bootstrap().catch((err) => {
  console.error("Critical: ErrorBase failed to boot up", err);
});
