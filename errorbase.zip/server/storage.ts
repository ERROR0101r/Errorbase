import { Router, Request, Response } from "express";
import fs from "fs";
import path from "path";
import multer from "multer";
import { Database } from "./db.ts";
import { authenticateUser } from "./auth.ts";

export const storageRouter = Router();

// Configure storage target path
const STORAGE_ROOT = path.join(process.cwd(), process.env.STORAGE_PATH || "uploads");
const MAX_UPLOAD_SIZE = Number(process.env.MAX_FILE_SIZE || "52428800"); // 50MB

// Ensure uploads container exists
if (!fs.existsSync(STORAGE_ROOT)) {
  fs.mkdirSync(STORAGE_ROOT, { recursive: true });
}

// Multer storage configuration
const storageEngine = multer.diskStorage({
  destination: (req, file, cb) => {
    const bucketName = req.params.bucketName;
    const bucketPath = path.join(STORAGE_ROOT, bucketName);
    
    if (!fs.existsSync(bucketPath)) {
      fs.mkdirSync(bucketPath, { recursive: true });
    }
    cb(null, bucketPath);
  },
  filename: (req, file, cb) => {
    // Keep original filename or sanitize it
    const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, "_");
    cb(null, sanitizedName);
  },
});

// MIME category validation: restrict to images, PDFs, videos
const fileFilter = (req: any, file: any, cb: any) => {
  const mime = file.mimetype;
  const allowed = [
    /^image\//,       // images
    /^video\//,       // videos
    /application\/pdf/ // PDF document
  ];

  const isValid = allowed.some((regex) => regex.test(mime));

  if (isValid) {
    cb(null, true);
  } else {
    cb(new Error("MIME Category Disallowed: ErrorBase storage only accepts images, PDFs (documents), and videos."), false);
  }
};

const uploadMiddleware = multer({
  storage: storageEngine,
  limits: { fileSize: MAX_UPLOAD_SIZE },
  fileFilter,
});

// Setup routers inside storage
storageRouter.use(authenticateUser);

// 1. Create a Bucket (POST /storage/v1/bucket)
storageRouter.post("/bucket", (req: Request, res: Response) => {
  const { name, is_public } = req.body;

  if (!name) {
    return res.status(400).json({ error: "Bucket name parameter is required." });
  }

  // Sanitize bucket name
  const sanitizedBucket = name.toLowerCase().replace(/[^a-z0-9\-_]/g, "");
  if (!sanitizedBucket) {
    return res.status(400).json({ error: "Invalid bucket name. Characters restricted to letters, numbers and dashes." });
  }

  // Create database state
  Database.createBucket(sanitizedBucket, !!is_public);

  // Check physical directory
  const physicalPath = path.join(STORAGE_ROOT, sanitizedBucket);
  if (!fs.existsSync(physicalPath)) {
    fs.mkdirSync(physicalPath, { recursive: true });
  }

  res.status(201).json({
    message: `Bucket '${sanitizedBucket}' created successfully.`,
    bucket: { name: sanitizedBucket, is_public: !!is_public },
  });
});

// 2. Fetch List of buckets (GET /storage/v1/bucket)
storageRouter.get("/bucket", (req: Request, res: Response) => {
  res.status(200).json(Database.getBuckets());
});

// 3. Delete bucket (DELETE /storage/v1/bucket/:bucketName)
storageRouter.delete("/bucket/:bucketName", (req: Request, res: Response) => {
  const bucketName = req.params.bucketName.toLowerCase();
  const bucketExists = Database.getBuckets().find((b) => b.name === bucketName);

  if (!bucketExists) {
    return res.status(404).json({ error: `Bucket '${bucketName}' stands unregistered.` });
  }

  // Wipe index
  Database.deleteBucket(bucketName);

  // Clear folder files physically
  const physicalPath = path.join(STORAGE_ROOT, bucketName);
  try {
    if (fs.existsSync(physicalPath)) {
      fs.rmSync(physicalPath, { recursive: true, force: true });
    }
  } catch (err: any) {
    console.error(`Failed to completely empty folder at ${physicalPath}`, err);
  }

  res.status(200).json({ message: `Bucket '${bucketName}' and all its assets cleared completely.` });
});

// 4. List files inside bucket (GET /storage/v1/bucket/:bucketName/list)
storageRouter.get("/bucket/:bucketName/list", (req: any, res: Response) => {
  const bucketName = req.params.bucketName.toLowerCase();
  const bucket = Database.getBuckets().find((b) => b.name === bucketName);

  if (!bucket) {
    return res.status(404).json({ error: `Bucket '${bucketName}' does not exist.` });
  }

  // Check policies: Private buckets require active authenticated session
  if (!bucket.is_public && !req.user) {
    return res.status(403).json({ error: `Bucket '${bucketName}' is private. Log in first.` });
  }

  res.status(200).json(Database.getFiles(bucketName));
});

// 5. Upload file (PUT /storage/v1/bucket/:bucketName/upload)
storageRouter.put("/bucket/:bucketName/upload", (req: any, res: Response) => {
  const bucketName = req.params.bucketName.toLowerCase();
  const bucket = Database.getBuckets().find((b) => b.name === bucketName);

  if (!bucket) {
    return res.status(404).json({ error: `Target bucket '${bucketName}' does not exist. Create it first.` });
  }

  // Authenticate write permissions
  if (!req.user) {
    return res.status(403).json({ error: "Access Denied: Log in to upload storage files." });
  }

  // Perform upload handling
  const singleUpload = uploadMiddleware.single("file");

  singleUpload(req, res, (err: any) => {
    if (err) {
      return res.status(400).json({ error: "Upload failed: " + err.message });
    }

    if (!req.file) {
      return res.status(400).json({ error: "No asset file detected. Include a file multi-part stream with 'file' key." });
    }

    const { filename, size, mimetype } = req.file;

    // Index database state
    Database.uploadFile(bucketName, filename, size, mimetype);

    res.status(200).json({
      message: "Asset loaded successfully.",
      file: {
        bucket: bucketName,
        path: filename,
        size,
        mimeType: mimetype,
        publicUrl: `/storage/v1/bucket/${bucketName}/download/${filename}`,
      },
    });
  });
});

// 6. Download file (GET /storage/v1/bucket/:bucketName/download/:filePath)
storageRouter.get("/bucket/:bucketName/download/:filePath", (req: any, res: Response) => {
  const bucketName = req.params.bucketName.toLowerCase();
  const filePath = req.params.filePath;

  const bucket = Database.getBuckets().find((b) => b.name === bucketName);
  if (!bucket) {
    return res.status(404).json({ error: "Target bucket does not exist." });
  }

  // Private authorization check
  if (!bucket.is_public && !req.user) {
    return res.status(403).json({ error: "Bucket storage access rejected. Log in to download." });
  }

  // Clean path to prevent directory traversal
  const sanitizedPath = path.basename(filePath);
  const diskLocation = path.join(STORAGE_ROOT, bucketName, sanitizedPath);

  if (!fs.existsSync(diskLocation)) {
    return res.status(404).json({ error: "Asset could not be found." });
  }

  // Send physical file
  res.sendFile(diskLocation);
});

// 7. Erase file (DELETE /storage/v1/bucket/:bucketName/delete/:filePath)
storageRouter.delete("/bucket/:bucketName/delete/:filePath", (req: any, res: Response) => {
  const bucketName = req.params.bucketName.toLowerCase();
  const filePath = req.params.filePath;

  if (!req.user) {
    return res.status(403).json({ error: "Unauthorized: Log in to delete bucket assets." });
  }

  const bucket = Database.getBuckets().find((b) => b.name === bucketName);
  if (!bucket) {
    return res.status(404).json({ error: "Target bucket does not exist." });
  }

  const sanitizedPath = path.basename(filePath);
  const diskLocation = path.join(STORAGE_ROOT, bucketName, sanitizedPath);

  // Erase index
  Database.deleteFile(bucketName, sanitizedPath);

  // Erase physical disk file
  try {
    if (fs.existsSync(diskLocation)) {
      fs.unlinkSync(diskLocation);
    }
  } catch (err: any) {
    console.error(`Failed to physical erase at ${diskLocation}`, err);
  }

  res.status(200).json({ message: "Asset successfully deleted." });
});
