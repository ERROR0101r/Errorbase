import { WebSocket, WebSocketServer } from "ws";
import http from "http";

interface RealtimeClient {
  ws: WebSocket;
  id: string;
  subscriptions: Set<string>; // topics
  presenceData?: Record<string, any>;
}

class RealtimeServerCoordinator {
  private clients = new Set<RealtimeClient>();

  public init(server: http.Server) {
    const wss = new WebSocketServer({ noServer: true });

    // Handle protocol upgrade manually to support standard express routing matching
    server.on("upgrade", (request, socket, head) => {
      const pathname = new URL(request.url || "", `http://${request.headers.host}`).pathname;

      if (pathname === "/realtime/v1/websocket") {
        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit("connection", ws, request);
        });
      }
    });

    wss.on("connection", (ws) => {
      const clientId = "client-" + Math.random().toString(36).substring(2, 9);
      const clientRecord: RealtimeClient = {
        ws,
        id: clientId,
        subscriptions: new Set<string>(),
      };

      this.clients.add(clientRecord);

      // Send initial acknowledgement
      ws.send(JSON.stringify({
        event: "system:connected",
        payload: { clientId, message: "Welcome to ErrorBase Realtime Engine" }
      }));

      ws.on("message", (rawMessage) => {
        try {
          const data = JSON.parse(rawMessage.toString());
          const { event, topic, payload } = data;

          if (event === "subscribe") {
            // Subscribe to channel/topic
            clientRecord.subscriptions.add(topic);
            
            ws.send(JSON.stringify({
              event: "system:subscribed",
              topic,
              payload: { success: true, message: `Subscribed to topic ${topic}` }
            }));

            // If postgres_changes subscription, notify client it is active
            if (topic.startsWith("postgres_changes:")) {
              ws.send(JSON.stringify({
                event: "postgres_changes_active",
                topic,
                payload: { status: "watching" }
              }));
            }

            // If presence subscription, announce self and supply active presence list
            if (topic.startsWith("presence:")) {
              clientRecord.presenceData = payload || { username: "Anonymous Developer", onlineAt: new Date().toISOString() };
              this.broadcastToTopic(topic, {
                event: "presence:join",
                topic,
                payload: { clientId, data: clientRecord.presenceData }
              });

              // Send back list of other active users in this topic
              const existingPresences: Record<string, any> = {};
              for (const other of this.clients) {
                if (other.id !== clientId && other.subscriptions.has(topic) && other.presenceData) {
                  existingPresences[other.id] = other.presenceData;
                }
              }
              ws.send(JSON.stringify({
                event: "presence:state",
                topic,
                payload: existingPresences
              }));
            }
          }

          if (event === "unsubscribe") {
            clientRecord.subscriptions.delete(topic);
            if (topic.startsWith("presence:")) {
              this.broadcastToTopic(topic, {
                event: "presence:leave",
                topic,
                payload: { clientId }
              });
            }
          }

          if (event === "broadcast") {
            // Send to ALL other clients subscribed to this topic
            this.broadcastToTopic(topic, {
              event: "broadcast",
              topic,
              payload
            }, clientId);
          }

          if (event === "presence:sync") {
            if (clientRecord.presenceData) {
              clientRecord.presenceData = { ...clientRecord.presenceData, ...payload };
              this.broadcastToTopic(topic, {
                event: "presence:update",
                topic,
                payload: { clientId, data: clientRecord.presenceData }
              });
            }
          }

        } catch (e) {
          ws.send(JSON.stringify({ event: "system:error", payload: { message: "Invalid JSON transmission." } }));
        }
      });

      ws.on("close", () => {
        // Unsubscribe from active presence channels and warn peers
        for (const topic of clientRecord.subscriptions) {
          if (topic.startsWith("presence:")) {
            this.broadcastToTopic(topic, {
              event: "presence:leave",
              topic,
              payload: { clientId }
            });
          }
        }
        this.clients.delete(clientRecord);
      });
    });

    console.log("Realtime WebSockets fully bound to server port 3000.");
  }

  // Broadcast DB migrations (INSERT, UPDATE, DELETE)
  public broadcastChange(table: string, eventType: "INSERT" | "UPDATE" | "DELETE", record: any) {
    const topic = `postgres_changes:${table}`;
    const payload = {
      eventType,
      schema: "public",
      table,
      record,
      commit_timestamp: new Date().toISOString(),
    };

    const messagePayload = {
      event: "postgres_changes",
      topic,
      payload,
    };

    this.broadcastToTopic(topic, messagePayload);
    // Also support wildcard listening topic: 'postgres_changes:*'
    this.broadcastToTopic(`postgres_changes:*`, {
      event: "postgres_changes",
      topic: `postgres_changes:${table}`,
      payload,
    });
  }

  // Utility to send to topic subscribers (excluding sender if needed)
  private broadcastToTopic(topic: string, message: any, excludeClientId?: string) {
    const msgStr = JSON.stringify(message);
    for (const client of this.clients) {
      if (client.id !== excludeClientId && client.subscriptions.has(topic)) {
        if (client.ws.readyState === WebSocket.OPEN) {
          try {
            client.ws.send(msgStr);
          } catch (err) {
            console.error(`Failed to dispatch socket event to client ${client.id}`, err);
          }
        }
      }
    }
  }
}

export const realtimeServer = new RealtimeServerCoordinator();
