import { Router, Response } from "express";
import { Database } from "./db.ts";
import { authenticateUser } from "./auth.ts";
import { realtimeServer } from "./realtime.ts";

export const restRouter = Router();

// Middleware inside restRouter to read auth state
restRouter.use(authenticateUser);

// RLS checker middleware helper
function checkRlsPermission(tableName: string, action: "read" | "write", req: any): { allowed: boolean; filterUserId?: string; error?: string } {
  const schema = Database.getTableSchema(tableName);
  if (!schema) {
    return { allowed: false, error: `Table '${tableName}' does not exist.` };
  }

  // If RLS is disabled, full access is allowed
  if (!schema.rls_enabled) {
    return { allowed: true };
  }

  const { policy } = schema;
  const user = req.user;

  if (policy === "public_all") {
    return { allowed: true };
  }

  if (policy === "public_read_auth_write") {
    if (action === "read") {
      return { allowed: true };
    }
    // write needs auth
    if (!user) {
      return { allowed: false, error: "Row-Level Security policy resists unauthorized writes. Log in first." };
    }
    return { allowed: true };
  }

  if (policy === "owner_only") {
    if (!user) {
      return { allowed: false, error: `Row-Level Security ('owner_only') blocks unauthenticated ${action} requests.` };
    }
    // Restrict queries to rows where owner_id = user.id
    return { allowed: true, filterUserId: user.id };
  }

  if (policy === "private") {
    return { allowed: false, error: "This table is private. Access locked by administrator." };
  }

  return { allowed: false, error: "Forbidden by RLS security directives." };
}

// Parse filter parameters from query (e.g. completed=eq.false  or  title=like.milk)
function parseQueryParams(query: Record<string, any>): Record<string, { op: string; val: string }> {
  const filters: Record<string, { op: string; val: string }> = {};

  for (const [key, rawVal] of Object.entries(query)) {
    // Ignore reserved PostgREST parameters
    if (["select", "order", "limit", "offset"].includes(key)) {
      continue;
    }

    if (typeof rawVal === "string") {
      const parts = rawVal.split(".");
      if (parts.length >= 2) {
        const op = parts[0].toLowerCase();
        const val = parts.slice(1).join("."); // join remaining if val contained dots
        filters[key] = { op, val };
      } else {
        filters[key] = { op: "eq", val: rawVal };
      }
    }
  }

  return filters;
}

// --- Rest AutoROUTES ---

// 1. GET REST Auto-API Read list of records
restRouter.get("/v1/:table", (req: any, res: Response) => {
  const tableName = req.params.table.toLowerCase();
  const schema = Database.getTableSchema(tableName);

  if (!schema) {
    return res.status(404).json({ error: `Table '${req.params.table}' was not found in schema definitions.` });
  }

  // Check RLS rules
  const rls = checkRlsPermission(tableName, "read", req);
  if (!rls.allowed) {
    return res.status(403).json({ error: rls.error });
  }

  let rows = [...Database.getRows(tableName)];

  // Apply RLS filter owner
  if (rls.filterUserId) {
    // Look for owner identifier columns (owner_id, user_id, profile_id, or standard creator)
    const columns = schema.columns.map((c) => c.name);
    const userIdCol = columns.find((col) => ["owner_id", "user_id", "profile_id", "id"].includes(col));
    if (userIdCol) {
      rows = rows.filter((row) => String(row[userIdCol]) === rls.filterUserId);
    } else {
      // If table has no user identifier, return empty for owner_only table to protect privacy
      rows = [];
    }
  }

  // Parse filters
  const filters = parseQueryParams(req.query);
  for (const [colName, f] of Object.entries(filters)) {
    rows = rows.filter((row) => {
      const rowVal = row[colName];
      if (rowVal === undefined) return false;

      const { op, val } = f;
      const strRowVal = String(rowVal).toLowerCase();
      const strVal = val.toLowerCase();

      if (op === "eq") return String(rowVal) === val;
      if (op === "ne") return String(rowVal) !== val;
      if (op === "like") return strRowVal.includes(strVal.replace(/%/g, ""));
      if (op === "gt") return Number(rowVal) > Number(val);
      if (op === "lt") return Number(rowVal) < Number(val);
      if (op === "in") {
        const list = val.replace(/^\(|\)$/g, "").split(",").map((x) => x.trim().toLowerCase());
        return list.includes(strRowVal);
      }
      return true;
    });
  }

  // Apply sorting: order=col.desc or order=col
  if (req.query.order) {
    const orderStr = req.query.order as string;
    const parts = orderStr.split(".");
    const colName = parts[0];
    const dir = parts[1] && parts[1].toLowerCase() === "desc" ? "desc" : "asc";

    rows.sort((a, b) => {
      const valA = a[colName];
      const valB = b[colName];
      if (valA === valB) return 0;
      if (valA === null || valA === undefined) return 1;
      if (valB === null || valB === undefined) return -1;
      const diff = valA < valB ? -1 : 1;
      return dir === "asc" ? diff : -diff;
    });
  }

  // Project Columns: select=col1,col2
  if (req.query.select) {
    const colsStr = req.query.select as string;
    if (colsStr !== "*") {
      const wantedCols = colsStr.split(",").map((c) => c.trim());
      rows = rows.map((row) => {
        const proj: Record<string, any> = {};
        for (const col of wantedCols) {
          if (row[col] !== undefined) {
            proj[col] = row[col];
          }
        }
        return proj;
      });
    }
  }

  // Apply limits & offsets
  const limitNum = req.query.limit ? parseInt(req.query.limit as string, 10) : 100;
  const offsetNum = req.query.offset ? parseInt(req.query.offset as string, 10) : 0;
  const slicedRows = rows.slice(offsetNum, offsetNum + limitNum);

  res.setHeader("Content-Range", `${offsetNum}-${offsetNum + slicedRows.length - 1}/${rows.length}`);
  res.status(200).json(slicedRows);
});

// 2. POST Insert dynamic record
restRouter.post("/v1/:table", (req: any, res: Response) => {
  const tableName = req.params.table.toLowerCase();
  const schema = Database.getTableSchema(tableName);

  if (!schema) {
    return res.status(404).json({ error: `Table '${req.params.table}' was not found in schema definitions.` });
  }

  // RLS Write Auth Check
  const rls = checkRlsPermission(tableName, "write", req);
  if (!rls.allowed) {
    return res.status(403).json({ error: rls.error });
  }

  const rowData = { ...req.body };

  // Set owner_id automatically if policy is owner_only
  if (rls.filterUserId) {
    const columns = schema.columns.map((c) => c.name);
    const ownerCol = columns.find((col) => col === "owner_id" || col === "user_id");
    if (ownerCol) {
      rowData[ownerCol] = rls.filterUserId;
    }
  }

  try {
    const inserted = Database.insertRow(tableName, rowData);

    // Notify realtime sockets
    realtimeServer.broadcastChange(tableName, "INSERT", inserted);

    res.status(201).json(inserted);
  } catch (err: any) {
    res.status(400).json({ error: "Failed to create database record: " + err.message });
  }
});

// 3. PATCH Update dynamic record(s)
restRouter.patch("/v1/:table", (req: any, res: Response) => {
  const tableName = req.params.table.toLowerCase();
  const schema = Database.getTableSchema(tableName);

  if (!schema) {
    return res.status(404).json({ error: `Table '${req.params.table}' was not found in schema definitions.` });
  }

  // RLS Check
  const rls = checkRlsPermission(tableName, "write", req);
  if (!rls.allowed) {
    return res.status(403).json({ error: rls.error });
  }

  const updateFilters = parseQueryParams(req.query);

  // If owner_only, enforce filters to protect privacy
  if (rls.filterUserId) {
    const columns = schema.columns.map((c) => c.name);
    const ownerCol = columns.find((col) => col === "owner_id" || col === "user_id");
    if (ownerCol) {
      updateFilters[ownerCol] = rls.filterUserId as any; // strictly lock
    }
  }

  try {
    const updatedRows = Database.updateRows(tableName, updateFilters, req.body);

    // Broadcast updates to realtime clients
    for (const u of updatedRows) {
      realtimeServer.broadcastChange(tableName, "UPDATE", u);
    }

    res.status(200).json(updatedRows);
  } catch (err: any) {
    res.status(400).json({ error: "Failed to apply database update: " + err.message });
  }
});

// 4. DELETE Remove dynamic record(s)
restRouter.delete("/v1/:table", (req: any, res: Response) => {
  const tableName = req.params.table.toLowerCase();
  const schema = Database.getTableSchema(tableName);

  if (!schema) {
    return res.status(404).json({ error: `Table '${req.params.table}' was not found in schema definitions.` });
  }

  // RLS check
  const rls = checkRlsPermission(tableName, "write", req);
  if (!rls.allowed) {
    return res.status(403).json({ error: rls.error });
  }

  const deleteFilters = parseQueryParams(req.query);

  // Auto-restrict deletes to owner_id if owner_only
  if (rls.filterUserId) {
    const columns = schema.columns.map((c) => c.name);
    const ownerCol = columns.find((col) => col === "owner_id" || col === "user_id");
    if (ownerCol) {
      deleteFilters[ownerCol] = rls.filterUserId as any;
    }
  }

  try {
    const deletedRows = Database.deleteRows(tableName, deleteFilters);

    // Broadcast deletions to realtime clients
    for (const d of deletedRows) {
      realtimeServer.broadcastChange(tableName, "DELETE", d);
    }

    res.status(200).json(deletedRows);
  } catch (err: any) {
    res.status(400).json({ error: "Failed to erase database record: " + err.message });
  }
});

// 5. GET rpc trigger support (simulating Stored Procedures)
restRouter.get("/rpc/:procedure", (req: any, res: Response) => {
  const procedure = req.params.procedure.toLowerCase();

  if (procedure === "get_total_todos") {
    const total = Database.getRows("todos").length;
    return res.status(200).json({ result: total });
  }

  if (procedure === "get_auth_count") {
    const count = Database.getUsers().length;
    return res.status(200).json({ result: count });
  }

  res.status(400).json({ error: `RPC function '${req.params.procedure}' has not been registered in ErrorBase.` });
});
