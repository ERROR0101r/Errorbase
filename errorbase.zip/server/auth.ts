import { Router, Request, Response, NextFunction } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { Database } from "./db.ts";

export const authRouter = Router();

// Secrets
const JWT_SECRET = process.env.JWT_SECRET || "errorbase-super-secret-key-change-this";
const REFRESH_SECRET = process.env.REFRESH_TOKEN_SECRET || "another-secret-key";
const SALT_ROUNDS = Number(process.env.SALT_ROUNDS || "10");

// In-memory Auth Rate limiter: Max 5 attempts per minute per IP
const authAttempts: Record<string, { count: number; windowStart: number }> = {};

function authRateLimiter(req: Request, res: Response, next: NextFunction) {
  const ip = (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress || "unknown-ip";
  const now = Date.now();
  const windowMs = 60 * 1000;

  if (!authAttempts[ip]) {
    authAttempts[ip] = { count: 1, windowStart: now };
    return next();
  }

  const session = authAttempts[ip];
  if (now - session.windowStart > windowMs) {
    // Reset window
    session.count = 1;
    session.windowStart = now;
    return next();
  }

  session.count++;
  if (session.count > 5) {
    Database.addLog({
      method: req.method,
      path: req.originalUrl,
      status: 429,
      ip,
      durationMs: 0,
    });
    return res.status(429).json({
      error: "Too many login/registration attempts. Please try again after 1 minute.",
    });
  }

  next();
}

// Generate tokens
function generateTokens(userId: string, email: string) {
  const accessToken = jwt.sign({ sub: userId, email }, JWT_SECRET, { expiresIn: "1h" });
  const refreshToken = jwt.sign({ sub: userId, email }, REFRESH_SECRET, { expiresIn: "7d" });
  return { accessToken, refreshToken };
}

// Set secure HTTP-only cookies
function setAuthCookies(res: Response, accessToken: string, refreshToken: string) {
  res.cookie("sb-access-token", accessToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 3600 * 1000, // 1 hour
  });

  res.cookie("sb-refresh-token", refreshToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 3600 * 1000, // 7 days
  });
}

// Clear auth cookies
function clearAuthCookies(res: Response) {
  res.clearCookie("sb-access-token");
  res.clearCookie("sb-refresh-token");
}

// Middleware to authenticate user from Bearer header OR HTTP-only cookie
export function authenticateUser(req: any, res: Response, next: NextFunction) {
  let token = "";

  // 1. Check cookies
  if (req.cookies && req.cookies["sb-access-token"]) {
    token = req.cookies["sb-access-token"];
  }

  // 2. Check Auth headers
  const authHeader = req.headers["authorization"];
  if (authHeader && authHeader.startsWith("Bearer ")) {
    token = authHeader.substring(7);
  }

  if (!token) {
    req.user = null;
    return next();
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET) as any;
    req.user = { id: payload.sub, email: payload.email };
  } catch (err) {
    req.user = null; // invalid token
  }

  next();
}

// Mandatory auth guard
export function requireAuth(req: any, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: "Unauthorized: Valid login session is required." });
  }
  next();
}

// --- Routes ---

// Signup
authRouter.post("/v1/signup", authRateLimiter, async (req: Request, res: Response) => {
  const { email, password, full_name } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required fields." });
  }

  // Check if exists
  const exists = Database.getUsers().find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (exists) {
    return res.status(400).json({ error: "User with this email is already registered." });
  }

  try {
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
    const userId = "usr-" + crypto.randomUUID().substring(0, 8);

    const newUser = {
      id: userId,
      email: email.toLowerCase(),
      passwordHash,
      created_at: new Date().toISOString(),
    };

    // Add user
    Database.addUser(newUser);

    // Create automatically profiles record to mirror profiles RLS triggers
    Database.insertRow("profiles", {
      id: userId,
      email: email.toLowerCase(),
      full_name: full_name || email.split("@")[0],
      updated_at: new Date().toISOString(),
    });

    const { accessToken, refreshToken } = generateTokens(userId, email);
    setAuthCookies(res, accessToken, refreshToken);

    res.status(201).json({
      user: { id: userId, email: email.toLowerCase() },
      session: { access_token: accessToken, refresh_token: refreshToken },
    });
  } catch (err: any) {
    res.status(500).json({ error: "Failed to registers. Server execution error: " + err.message });
  }
});

// Signin
authRouter.post("/v1/signin", authRateLimiter, async (req: Request, res: Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Both email and password are required." });
  }

  const user = Database.getUsers().find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    return res.status(400).json({ error: "Invalid login credentials." });
  }

  try {
    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) {
      return res.status(400).json({ error: "Invalid login credentials." });
    }

    const { accessToken, refreshToken } = generateTokens(user.id, user.email);
    setAuthCookies(res, accessToken, refreshToken);

    res.status(200).json({
      user: { id: user.id, email: user.email },
      session: { access_token: accessToken, refresh_token: refreshToken },
    });
  } catch (err: any) {
    res.status(500).json({ error: "Server authentication error: " + err.message });
  }
});

// Fetch current user details
authRouter.get("/v1/user", authenticateUser, (req: any, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: "Not logged in or session expired." });
  }
  res.status(200).json({ user: req.user });
});

// Invalidate token / Logout
authRouter.post("/v1/logout", (req: Request, res: Response) => {
  clearAuthCookies(res);
  res.status(200).json({ message: "Successfully logged out." });
});

// Refresh tokens
authRouter.post("/v1/refresh", (req: Request, res: Response) => {
  let refreshToken = req.cookies["sb-refresh-token"];

  if (!refreshToken && req.body.refresh_token) {
    refreshToken = req.body.refresh_token;
  }

  if (!refreshToken) {
    return res.status(400).json({ error: "Refresh token is missing." });
  }

  try {
    const payload = jwt.verify(refreshToken, REFRESH_SECRET) as any;
    const { accessToken: newAccess, refreshToken: newRefresh } = generateTokens(payload.sub, payload.email);

    setAuthCookies(res, newAccess, newRefresh);
    res.status(200).json({
      session: { access_token: newAccess, refresh_token: newRefresh },
    });
  } catch (err) {
    clearAuthCookies(res);
    res.status(401).json({ error: "Invalid or expired refresh token. Please sign in again." });
  }
});

// Password reset triggers
authRouter.post("/v1/recover", (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Email is required to dispatch recovery request." });
  }

  // Simulate email trigger
  res.status(200).json({
    message: "Recovery pipeline triggered! Password reset link dispatched to " + email + " (Simulation).",
  });
});
