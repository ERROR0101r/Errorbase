import fs from "fs";
import path from "path";
import crypto from "crypto";

export interface Column {
  name: string;
  type: "text" | "number" | "boolean" | "timestamp";
  is_primary: boolean;
  default_value?: any;
}

export type RlsPolicy = "public_all" | "public_read_auth_write" | "owner_only" | "private";

export interface TableSchema {
  name: string;
  rls_enabled: boolean;
  policy: RlsPolicy;
  columns: Column[];
}

export interface AuthUser {
  id: string;
  email: string;
  passwordHash: string;
  created_at: string;
}

export interface StorageBucket {
  name: string;
  is_public: boolean;
  created_at: string;
}

export interface StorageFile {
  bucket: string;
  path: string;
  size: number;
  mimeType: string;
  updatedAt: string;
}

export interface ApiLog {
  id: string;
  timestamp: string;
  method: string;
  path: string;
  status: number;
  ip: string;
  durationMs: number;
}

export interface DbState {
  users: AuthUser[];
  tables: Record<string, TableSchema>;
  rows: Record<string, Array<Record<string, any>>>;
  buckets: Record<string, StorageBucket>;
  files: StorageFile[];
  logs: ApiLog[];
}

const DATA_DIR = path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "errorbase_db.json");

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export class Database {
  private static state: DbState = Database.load();

  private static load(): DbState {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, "utf-8");
        return JSON.parse(raw);
      }
    } catch (err) {
      console.error("Failed to load db state, initializing default schema", err);
    }
    return Database.getInitialState();
  }

  public static save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.state, null, 2), "utf-8");
    } catch (err) {
      console.error("Failed to save db state", err);
    }
  }

  private static getInitialState(): DbState {
    const users: AuthUser[] = [
      {
        id: "usr-demo123",
        email: "demo@errorbase.dev",
        // 'demo123' bcrypt-like hash or simple sha256
        passwordHash: "$2b$10$tZ2pW9pC9Q6kGeH0h7S7EuH6o8rT9u0Xk9uS6mF9V.n7ZgV9f8aXm", // simulated/real bcrypt
        created_at: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
      },
    ];

    const tables: Record<string, TableSchema> = {
      profiles: {
        name: "profiles",
        rls_enabled: true,
        policy: "public_read_auth_write",
        columns: [
          { name: "id", type: "text", is_primary: true },
          { name: "email", type: "text", is_primary: false },
          { name: "full_name", type: "text", is_primary: false },
          { name: "updated_at", type: "timestamp", is_primary: false },
        ],
      },
      todos: {
        name: "todos",
        rls_enabled: true,
        policy: "owner_only",
        columns: [
          { name: "id", type: "text", is_primary: true },
          { name: "title", type: "text", is_primary: false },
          { name: "completed", type: "boolean", is_primary: false, default_value: false },
          { name: "owner_id", type: "text", is_primary: false },
          { name: "created_at", type: "timestamp", is_primary: false },
        ],
      },
    };

    const rows: Record<string, Array<Record<string, any>>> = {
      profiles: [
        {
          id: "usr-demo123",
          email: "demo@errorbase.dev",
          full_name: "Demo Developer",
          updated_at: new Date().toISOString(),
        },
      ],
      todos: [
        {
          id: "todo-1",
          title: "Explore ErrorBase Dynamic API Builder",
          completed: false,
          owner_id: "usr-demo123",
          created_at: new Date(Date.now() - 3600 * 1000).toISOString(),
        },
        {
          id: "todo-2",
          title: "Build custom database schema",
          completed: true,
          owner_id: "usr-demo123",
          created_at: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
        },
      ],
    };

    const buckets: Record<string, StorageBucket> = {
      avatars: {
        name: "avatars",
        is_public: true,
        created_at: new Date().toISOString(),
      },
      documents: {
        name: "documents",
        is_public: false,
        created_at: new Date().toISOString(),
      },
    };

    return {
      users,
      tables,
      rows,
      buckets,
      files: [],
      logs: [],
    };
  }

  // --- Users Operation ---
  public static getUsers(): AuthUser[] {
    return this.state.users;
  }

  public static addUser(user: AuthUser) {
    this.state.users.push(user);
    this.save();
  }

  // --- Tables Schema ---
  public static getTables(): TableSchema[] {
    return Object.values(this.state.tables);
  }

  public static getTableSchema(name: string): TableSchema | undefined {
    return this.state.tables[name];
  }

  public static addTable(table: TableSchema) {
    this.state.tables[table.name] = table;
    if (!this.state.rows[table.name]) {
      this.state.rows[table.name] = [];
    }
    this.save();
  }

  public static removeTable(name: string) {
    delete this.state.tables[name];
    delete this.state.rows[name];
    this.save();
  }

  public static updateTablePolicy(name: string, rls_enabled: boolean, policy: RlsPolicy) {
    if (this.state.tables[name]) {
      this.state.tables[name].rls_enabled = rls_enabled;
      this.state.tables[name].policy = policy;
      this.save();
    }
  }

  // --- Rows Operations ---
  public static getRows(table: string): any[] {
    return this.state.rows[table] || [];
  }

  public static setRows(table: string, rows: any[]) {
    this.state.rows[table] = rows;
    this.save();
  }

  public static insertRow(table: string, rowData: Record<string, any>): any {
    if (!this.state.rows[table]) {
      this.state.rows[table] = [];
    }
    const schema = this.state.tables[table];
    const newRow: Record<string, any> = {};

    // Fill defaults and validate types
    if (schema) {
      for (const col of schema.columns) {
        let val = rowData[col.name];
        if (val === undefined) {
          if (col.is_primary) {
            val = col.type === "number" ? Date.now() : crypto.randomUUID();
          } else if (col.default_value !== undefined) {
            val = col.default_value;
          } else if (col.type === "timestamp") {
            val = new Date().toISOString();
          } else {
            val = null;
          }
        }
        newRow[col.name] = val;
      }
    } else {
      // Freeform table fallback
      newRow.id = rowData.id || crypto.randomUUID();
      Object.assign(newRow, rowData);
    }

    this.state.rows[table].push(newRow);
    this.save();
    return newRow;
  }

  public static updateRows(table: string, queryFilters: any, updateData: Record<string, any>): any[] {
    const tableRows = this.state.rows[table] || [];
    const schema = this.state.tables[table];
    const updated: any[] = [];

    // Filter matching rows
    const matches = tableRows.map((row) => {
      let isMatch = true;
      for (const [key, filter] of Object.entries(queryFilters)) {
        const rowVal = row[key];
        // simple equality check
        if (typeof filter === "object" && filter !== null) {
          const { op, val } = filter as any;
          if (op === "eq" && String(rowVal) !== String(val)) isMatch = false;
          if (op === "ne" && String(rowVal) === String(val)) isMatch = false;
          if (op === "gt" && Number(rowVal) <= Number(val)) isMatch = false;
          if (op === "lt" && Number(rowVal) >= Number(val)) isMatch = false;
          if (op === "like" && !String(rowVal).toLowerCase().includes(String(val).toLowerCase())) isMatch = false;
        } else {
          if (String(rowVal) !== String(filter)) isMatch = false;
        }
      }
      return isMatch;
    });

    for (let i = 0; i < tableRows.length; i++) {
      if (matches[i]) {
        const row = tableRows[i];
        const newRow = { ...row, ...updateData };
        // Ensure primary key is unmodified
        if (schema) {
          const pk = schema.columns.find((c) => c.is_primary);
          if (pk && row[pk.name] !== undefined) {
            newRow[pk.name] = row[pk.name]; // protect PK
          }
        }
        tableRows[i] = newRow;
        updated.push(newRow);
      }
    }

    this.save();
    return updated;
  }

  public static deleteRows(table: string, queryFilters: any): any[] {
    const tableRows = this.state.rows[table] || [];
    const remaining: any[] = [];
    const deleted: any[] = [];

    for (const row of tableRows) {
      let isMatch = true;
      for (const [key, filter] of Object.entries(queryFilters)) {
        const rowVal = row[key];
        if (typeof filter === "object" && filter !== null) {
          const { op, val } = filter as any;
          if (op === "eq" && String(rowVal) !== String(val)) isMatch = false;
          if (op === "ne" && String(rowVal) === String(val)) isMatch = false;
          if (op === "gt" && Number(rowVal) <= Number(val)) isMatch = false;
          if (op === "lt" && Number(rowVal) >= Number(val)) isMatch = false;
        } else {
          if (String(rowVal) !== String(filter)) isMatch = false;
        }
      }

      if (isMatch) {
        deleted.push(row);
      } else {
        remaining.push(row);
      }
    }

    this.state.rows[table] = remaining;
    this.save();
    return deleted;
  }

  // --- Real storage buckets ---
  public static getBuckets(): StorageBucket[] {
    return Object.values(this.state.buckets);
  }

  public static createBucket(name: string, is_public: boolean) {
    this.state.buckets[name] = {
      name,
      is_public,
      created_at: new Date().toISOString(),
    };
    this.save();
  }

  public static deleteBucket(name: string) {
    delete this.state.buckets[name];
    this.state.files = this.state.files.filter((f) => f.bucket !== name);
    this.save();
  }

  public static getFiles(bucketName: string): StorageFile[] {
    return this.state.files.filter((f) => f.bucket === bucketName);
  }

  public static uploadFile(bucket: string, filePath: string, size: number, mimeType: string) {
    // Upsert file
    this.state.files = this.state.files.filter((f) => !(f.bucket === bucket && f.path === filePath));
    this.state.files.push({
      bucket,
      path: filePath,
      size,
      mimeType,
      updatedAt: new Date().toISOString(),
    });
    this.save();
  }

  public static deleteFile(bucket: string, filePath: string) {
    this.state.files = this.state.files.filter((f) => !(f.bucket === bucket && f.path === filePath));
    this.save();
  }

  // --- Api Logs & Metrics ---
  public static addLog(log: Omit<ApiLog, "id" | "timestamp">) {
    const fullLog: ApiLog = {
      id: "log-" + crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      ...log,
    };
    this.state.logs.unshift(fullLog);
    // Limit to 100 entries
    if (this.state.logs.length > 200) {
      this.state.logs = this.state.logs.slice(0, 200);
    }
    this.save();
  }

  public static getLogs(): ApiLog[] {
    return this.state.logs;
  }

  // --- Direct SQL Query parses and run logic ---
  public static executeSql(query: string): { success: boolean; data: any[]; affectedRows?: number; schemaChanged?: boolean; error?: string } {
    const r = query.trim().replace(/;+$/, "").trim();
    const cleanSql = r.replace(/\s+/g, " ");

    try {
      // 1. SELECT * FROM table [WHERE] [ORDER BY] [LIMIT]
      const selectMatch = cleanSql.match(/^SELECT\s+(.+?)\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+?))?(?:\s+ORDER\s+BY\s+(\w+)(?:\s+(ASC|DESC))?)?(?:\s+LIMIT\s+(\d+))?$/i);
      if (selectMatch) {
        const [, selectColsStr, tableName, whereClause, orderByCol, orderDir, limitVal] = selectMatch;
        const targetTable = tableName.toLowerCase();
        if (!this.state.rows[targetTable]) {
          return { success: false, data: [], error: `Table '${tableName}' does not exist.` };
        }

        let result = [...this.state.rows[targetTable]];

        // Simple single WHERE parser (e.g. key = 'val', or key = val, or key LIKE '%val%')
        if (whereClause) {
          const parts = whereClause.split(/\s+(=|!=|>|<|like)\s+/i);
          if (parts.length >= 3) {
            const keyCol = parts[0].trim();
            const operator = parts[1].toLowerCase();
            let rawVal = parts[2].trim();
            // clean quotes
            if ((rawVal.startsWith("'") && rawVal.endsWith("'")) || (rawVal.startsWith('"') && rawVal.endsWith('"'))) {
              rawVal = rawVal.slice(1, -1);
            }

            result = result.filter((row) => {
              const rowVal = row[keyCol];
              if (operator === "=") return String(rowVal) === rawVal;
              if (operator === "!=") return String(rowVal) !== rawVal;
              if (operator === "like") {
                const search = rawVal.replace(/%/g, "");
                return String(rowVal).toLowerCase().includes(search.toLowerCase());
              }
              const numRow = Number(rowVal);
              const numQuery = Number(rawVal);
              if (operator === ">") return numRow > numQuery;
              if (operator === "<") return numRow < numQuery;
              return true;
            });
          }
        }

        // Sorting
        if (orderByCol) {
          const dir = (orderDir || "ASC").toUpperCase();
          result.sort((a, b) => {
            const valA = a[orderByCol];
            const valB = b[orderByCol];
            if (valA === valB) return 0;
            if (valA === undefined || valA === null) return 1;
            if (valB === undefined || valB === null) return -1;
            const diff = valA < valB ? -1 : 1;
            return dir === "ASC" ? diff : -diff;
          });
        }

        // Project columns
        if (selectColsStr !== "*") {
          const colsList = selectColsStr.split(",").map((c) => c.trim());
          result = result.map((row) => {
            const obj: Record<string, any> = {};
            for (const col of colsList) {
              obj[col] = row[col];
            }
            return obj;
          });
        }

        // Limit
        if (limitVal) {
          result = result.slice(0, parseInt(limitVal, 10));
        }

        return { success: true, data: result };
      }

      // 2. INSERT INTO table (cols) VALUES (vals)
      const insertMatch = cleanSql.match(/^INSERT\s+INTO\s+(\w+)\s*\((.+?)\)\s*VALUES\s*\((.+?)\)$/i);
      if (insertMatch) {
        const [, tableName, colsStr, valsStr] = insertMatch;
        const targetTable = tableName.toLowerCase();
        if (!this.state.rows[targetTable]) {
          return { success: false, data: [], error: `Table '${tableName}' does not exist.` };
        }

        const cols = colsStr.split(",").map((c) => c.trim());
        const vals = valsStr.split(",").map((v) => {
          let trimmed = v.trim();
          if ((trimmed.startsWith("'") && trimmed.endsWith("'")) || (trimmed.startsWith('"') && trimmed.endsWith('"'))) {
            return trimmed.slice(1, -1);
          }
          if (trimmed.toLowerCase() === "true") return true;
          if (trimmed.toLowerCase() === "false") return false;
          if (!isNaN(Number(trimmed))) return Number(trimmed);
          return trimmed;
        });

        if (cols.length !== vals.length) {
          return { success: false, data: [], error: "Column count does not match values count." };
        }

        const insertObj: Record<string, any> = {};
        for (let i = 0; i < cols.length; i++) {
          insertObj[cols[i]] = vals[i];
        }

        const inserted = this.insertRow(targetTable, insertObj);
        return { success: true, data: [inserted], affectedRows: 1 };
      }

      // 3. CREATE TABLE name (col typ, ...)
      const createMatch = cleanSql.match(/^CREATE\s+TABLE\s+(\w+)\s*\((.+?)\)$/i);
      if (createMatch) {
        const [, tableName, colsDefStr] = createMatch;
        const targetTableName = tableName.toLowerCase();
        if (this.state.tables[targetTableName]) {
          return { success: false, data: [], error: `Table '${tableName}' already exists.` };
        }

        const colDefs = colsDefStr.split(",").map((d) => d.trim());
        const columns: Column[] = [];

        for (const def of colDefs) {
          const words = def.split(/\s+/);
          const name = words[0];
          let typeWord = (words[1] || "text").toLowerCase();
          const is_primary = def.toLowerCase().includes("primary key");

          let type: "text" | "number" | "boolean" | "timestamp" = "text";
          if (typeWord.includes("int") || typeWord.includes("number") || typeWord.includes("double") || typeWord.includes("float")) {
            type = "number";
          } else if (typeWord.includes("bool")) {
            type = "boolean";
          } else if (typeWord.includes("time") || typeWord.includes("date")) {
            type = "timestamp";
          }

          columns.push({
            name,
            type,
            is_primary,
          });
        }

        // Add typical PK if not defined
        if (!columns.some((c) => c.is_primary)) {
          columns.unshift({ name: "id", type: "text", is_primary: true });
        }

        this.addTable({
          name: targetTableName,
          rls_enabled: false,
          policy: "public_all",
          columns,
        });

        return { success: true, data: [], affectedRows: 0, schemaChanged: true };
      }

      // 4. DROP TABLE name
      const dropMatch = cleanSql.match(/^DROP\s+TABLE\s+(\w+)$/i);
      if (dropMatch) {
        const [, tableName] = dropMatch;
        const targetTableName = tableName.toLowerCase();
        if (!this.state.tables[targetTableName]) {
          return { success: false, data: [], error: `Table '${tableName}' does not exist.` };
        }

        this.removeTable(targetTableName);
        return { success: true, data: [], affectedRows: 0, schemaChanged: true };
      }

      // 5. DELETE FROM table [WHERE]
      const deleteMatch = cleanSql.match(/^DELETE\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+?))?$/i);
      if (deleteMatch) {
        const [, tableName, whereClause] = deleteMatch;
        const targetTable = tableName.toLowerCase();
        if (!this.state.rows[targetTable]) {
          return { success: false, data: [], error: `Table '${tableName}' does not exist.` };
        }

        const filters: Record<string, any> = {};
        if (whereClause) {
          const parts = whereClause.split(/\s*(=)\s*/);
          if (parts.length >= 3) {
            const k = parts[0].trim();
            let v = parts[2].trim();
            if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith('"') && v.endsWith('"'))) {
              v = v.slice(1, -1);
            }
            filters[k] = v;
          }
        }

        const deleted = this.deleteRows(targetTable, filters);
        return { success: true, data: deleted, affectedRows: deleted.length };
      }

      return {
        success: false,
        data: [],
        error: "SQL query type not supported directly. ErrorBase Console supports: CREATE TABLE, SELECT, INSERT, DELETE & DROP TABLE commands.",
      };

    } catch (e: any) {
      return { success: false, data: [], error: e.message || "SQL Execution error" };
    }
  }
}
