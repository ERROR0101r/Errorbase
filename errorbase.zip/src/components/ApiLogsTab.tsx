import React, { useState } from "react";
import { ApiLog } from "../types.ts";
import { Activity, ShieldCheck, ShieldAlert, Wifi, Globe, Trash } from "lucide-react";

interface ApiLogsProps {
  logs: ApiLog[];
  onClearLogs: () => void;
}

export default function ApiLogsTab({ logs, onClearLogs }: ApiLogsProps) {
  const [methodFilter, setMethodFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");

  // Filter list
  const filteredLogs = logs.filter((l) => {
    const matchesMethod = methodFilter === "ALL" || l.method === methodFilter;
    let matchesStatus = true;
    if (statusFilter === "SUCCESS") {
      matchesStatus = l.status >= 200 && l.status < 300;
    } else if (statusFilter === "ERRORS") {
      matchesStatus = l.status >= 400;
    }
    return matchesMethod && matchesStatus;
  });

  // Calculate metrics
  const totalLogs = logs.length;
  const errorLogsCount = logs.filter((l) => l.status >= 400).length;
  const avgLatency = totalLogs > 0 ? logs.reduce((acc, current) => acc + current.durationMs, 0) / totalLogs : 0;
  const errorRate = totalLogs > 0 ? (errorLogsCount / totalLogs) * 105 : 0; // scaled slightly for visuals

  // Style helper for Status codes
  const resolveStatusColorClass = (code: number) => {
    if (code >= 200 && code < 300) return "bg-emerald-50 text-emerald-700 border border-emerald-150";
    if (code >= 300 && code < 400) return "bg-indigo-50 text-indigo-700 border border-indigo-150";
    if (code >= 400 && code < 500) return "bg-amber-50 text-amber-700 border border-amber-150";
    return "bg-rose-50 text-rose-700 border border-rose-150";
  };

  // Style helper for HTTP methods
  const resolveMethodClass = (m: string) => {
    const raw = m.toUpperCase();
    if (raw === "GET") return "text-emerald-600 font-bold bg-emerald-50/50 px-1.5 py-0.5 rounded border border-emerald-100/60";
    if (raw === "POST") return "text-indigo-600 font-bold bg-indigo-50/50 px-1.5 py-0.5 rounded border border-indigo-100/60";
    if (raw === "PATCH" || raw === "PUT") return "text-amber-600 font-bold bg-amber-50/50 px-1.5 py-0.5 rounded border border-amber-100/60";
    return "text-rose-600 font-bold bg-rose-50/50 px-1.5 py-0.5 rounded border border-rose-100/60";
  };

  return (
    <div className="space-y-6" id="api-logs-tab-root">
      {/* Analytics widgets metrics breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="analytics-widgets-grid">
        {/* Total traffic volume cards */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4" id="metric-vol-card">
          <div className="flex justify-between items-center text-xs">
            <span className="font-semibold text-slate-500 uppercase tracking-tighter">API Request Volume</span>
            <span className="text-emerald-500 font-semibold flex items-center gap-1">
              <Wifi className="h-3 w-3 animate-pulse" /> Live traffic stream
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-extrabold text-slate-800 tracking-tight">{totalLogs}</h3>
            <span className="text-xs text-slate-400">Total processed actions</span>
          </div>
          {/* Mock visual SVG wave */}
          <div className="h-10 w-full bg-slate-50 border border-slate-100 rounded-lg overflow-hidden relative">
            <svg className="absolute bottom-0 left-0 w-full h-8 text-indigo-500/10 fill-current" viewBox="0 0 100 10" preserveAspectRatio="none">
              <path d="M0,5 C30,1 70,9 100,2 L100,10 L0,10 Z" />
            </svg>
            <svg className="absolute bottom-0 left-0 w-full h-6 text-indigo-500/20 fill-current" viewBox="0 0 100 10" preserveAspectRatio="none">
              <path d="M0,6 C40,9 60,2 100,4 L100,10 L0,10 Z" />
            </svg>
          </div>
        </div>

        {/* Latency Average widgets */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4" id="metric-latency-card">
          <div className="flex justify-between items-center text-xs">
            <span className="font-semibold text-slate-500 uppercase tracking-tighter">System Average Latency</span>
            <Activity className="h-4.5 w-4.5 text-indigo-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-extrabold text-slate-800 tracking-tight">{avgLatency.toFixed(1)} ms</h3>
            <span className="text-xs text-slate-400">Network execution speed</span>
          </div>
          {/* Simulated progress slider indicating latency speed limits */}
          <div className="space-y-1">
            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 to-indigo-500 rounded-full transition-all duration-500"
                style={{ width: `${Math.min((avgLatency / 150) * 100, 100)}%` }}
              />
            </div>
            <div className="flex justify-between text-[9px] text-slate-400 font-mono">
              <span>Fast (0ms)</span>
              <span>Slow (300ms)</span>
            </div>
          </div>
        </div>

        {/* Success / Failure rates card */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4" id="metric-health-card">
          <div className="flex justify-between items-center text-xs">
            <span className="font-semibold text-slate-500 uppercase tracking-tighter">API Response safety Rate</span>
            {errorLogsCount === 0 ? (
              <ShieldCheck className="h-4.5 w-4.5 text-emerald-500" />
            ) : (
              <ShieldAlert className="h-4.5 w-4.5 text-rose-500" />
            )}
          </div>
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-extrabold text-slate-800 tracking-tight">
              {totalLogs === 0 ? "100.0" : (100 - (errorLogsCount / totalLogs) * 100).toFixed(1)}%
            </h3>
            <span className="text-xs text-slate-400">Request success indices</span>
          </div>
          <div className="space-y-1">
            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${errorLogsCount === 0 ? "bg-emerald-500" : "bg-indigo-500"}`}
                style={{ width: `${totalLogs === 0 ? 100 : (100 - (errorLogsCount / totalLogs) * 100)}%` }}
              />
            </div>
            <div className="flex justify-between text-[9px] text-slate-400 font-mono">
              <span>System errors: {errorLogsCount}</span>
              <span>Stable</span>
            </div>
          </div>
        </div>
      </div>

      {/* Logger table and filters panel */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden flex flex-col" id="logs-tracker-sheet">
        {/* filter controls row */}
        <div className="p-4 bg-slate-50 border-b border-slate-150 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-800">Dynamic Logging Terminal</h3>
            <p className="text-[10px] text-slate-400">Live records auditing processed database queries, authentication validations, and API downloads.</p>
          </div>

          <div className="flex items-center gap-2 text-xs flex-wrap">
            {/* Method filter option */}
            <select
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value)}
              className="p-1 px-1.5 rounded border border-slate-200 bg-white"
            >
              <option value="ALL">All Methods</option>
              <option value="GET">GET</option>
              <option value="POST">POST</option>
              <option value="PATCH">PATCH</option>
              <option value="DELETE">DELETE</option>
            </select>

            {/* Status filter option */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="p-1 px-1.5 rounded border border-slate-200 bg-white"
            >
              <option value="ALL">All Codes</option>
              <option value="SUCCESS">Success (2xx)</option>
              <option value="ERRORS">Errors (4xx+)</option>
            </select>

            {/* Erase Logs cache */}
            <button
              onClick={onClearLogs}
              className="p-1 px-2.5 rounded hover:bg-rose-50 text-rose-600 border border-rose-200 font-semibold text-[11px] flex items-center gap-1 transition-colors bg-white hover:border-rose-300"
              title="Clear all stored logging metrics memory"
            >
              <Trash className="h-3 w-3" /> Clear Logs
            </button>
          </div>
        </div>

        {/* Streaming Logs sheet */}
        <div className="overflow-x-auto max-h-[380px] overflow-y-auto" id="logs-sheet-scroller">
          <table className="w-full text-xs text-left border-collapse" id="logs-streaming-table">
            <thead className="bg-slate-50 border-b border-slate-100 font-mono font-medium text-slate-400 uppercase text-[9px] tracking-wider select-none">
              <tr>
                <th className="px-4 py-2.5">HTTP Method</th>
                <th className="px-4 py-2.5">Requested Endpoint Path</th>
                <th className="px-4 py-2.5">Response Token</th>
                <th className="px-4 py-2.5">Connecting client IP</th>
                <th className="px-4 py-2.5">Responding delay</th>
                <th className="px-4 py-2.5">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400 font-sans">
                    No matching logs indexed in this filter window. Trigger some REST actions first!
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/40 select-all">
                    <td className="px-4 py-2">
                      <span className={resolveMethodClass(log.method)}>{log.method}</span>
                    </td>
                    <td className="px-4 py-2 font-semibold text-slate-700 truncate max-w-[150px]" title={log.path}>
                      {log.path}
                    </td>
                    <td className="px-4 py-2">
                      <span className={`inline-flex px-2 py-0.5 rounded-full font-bold text-[10px] ${resolveStatusColorClass(log.status)}`}>
                        {log.status}
                      </span>
                    </td>
                    <td className="px-4 py-2 text-slate-400 flex items-center gap-1 pt-3 border-0">
                      <Globe className="h-3.5 w-3.5" />
                      {log.ip}
                    </td>
                    <td className={`px-4 py-2 font-semibold ${log.durationMs > 200 ? "text-amber-500" : "text-emerald-500"}`}>
                      {log.durationMs} ms
                    </td>
                    <td className="px-4 py-2 text-[10px] text-slate-400 font-sans">
                      {new Date(log.timestamp).toLocaleTimeString()} ({new Date(log.timestamp).toLocaleDateString()})
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
