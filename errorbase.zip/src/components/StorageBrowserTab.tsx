import React, { useState, useEffect } from "react";
import { StorageBucket, StorageFile } from "../types.ts";
import { Folder, FolderPlus, Trash2, UploadCloud, Copy, Check, Download, FileText, Image, Video, ShieldAlert, ShieldCheck } from "lucide-react";

interface StorageBrowserProps {
  buckets: StorageBucket[];
  onRefresh: () => void;
  apiUrl: string;
}

export default function StorageBrowserTab({ buckets, onRefresh, apiUrl }: StorageBrowserProps) {
  const [selectedBucket, setSelectedBucket] = useState<StorageBucket | null>(null);
  const [files, setFiles] = useState<StorageFile[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  // Bucket creator details
  const [isCreatingBucket, setIsCreatingBucket] = useState(false);
  const [newBucketName, setNewBucketName] = useState("");
  const [newBucketPublic, setNewBucketPublic] = useState(true);

  useEffect(() => {
    if (buckets.length > 0 && !selectedBucket) {
      setSelectedBucket(buckets[0]);
    }
  }, [buckets, selectedBucket]);

  useEffect(() => {
    if (selectedBucket) {
      fetchFiles(selectedBucket.name);
    } else {
      setFiles([]);
    }
  }, [selectedBucket]);

  const fetchFiles = async (bucketName: string) => {
    setLoadingFiles(true);
    setErrorMsg(null);
    try {
      const res = await fetch(`${apiUrl}/storage/v1/bucket/${bucketName}/list`);
      if (res.ok) {
        const data = await res.json();
        setFiles(data);
      } else {
        const err = await res.json();
        setErrorMsg(err.error || `Failed to fetch elements for bucket '${bucketName}'.`);
      }
    } catch {
      setErrorMsg("Network failure retrieving files.");
    } finally {
      setLoadingFiles(false);
    }
  };

  const handleCreateBucket = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const name = newBucketName.trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
    if (!name) {
      setErrorMsg("Bucket name contains disallowed character spacing.");
      return;
    }

    try {
      const res = await fetch(`${apiUrl}/storage/v1/bucket`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, is_public: newBucketPublic }),
      });

      if (res.ok) {
        setSuccessMsg(`Bucket container '${name}' built successfully.`);
        setNewBucketName("");
        setIsCreatingBucket(false);
        onRefresh();
      } else {
        const err = await res.json();
        setErrorMsg(err.error || "Failed to finalize bucket setup.");
      }
    } catch {
      setErrorMsg("Failed to reach server.");
    }
  };

  const handleDeleteBucket = async (bucketName: string) => {
    if (!confirm(`Are you sure you want to drop storage bucket '${bucketName}' and its files? This is irreversible!`)) return;
    setErrorMsg(null);
    try {
      const res = await fetch(`${apiUrl}/storage/v1/bucket/${bucketName}`, { method: "DELETE" });
      if (res.ok) {
        setSuccessMsg(`Bucket '${bucketName}' dropped cleanly.`);
        setSelectedBucket(null);
        onRefresh();
      } else {
        const err = await res.json();
        setErrorMsg(err.error || "Failed to drop bucket.");
      }
    } catch {
      setErrorMsg("Network execution failure dropping bucket.");
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedBucket || !e.target.files || e.target.files.length === 0) return;
    setErrorMsg(null);
    setSuccessMsg(null);
    setUploading(true);

    const selectedFile = e.target.files[0];
    const formData = new FormData();
    formData.append("file", selectedFile);

    try {
      const res = await fetch(`${apiUrl}/storage/v1/bucket/${selectedBucket.name}/upload`, {
        method: "PUT",
        body: formData, // do NOT define content-type header for multipart upload, browser binds boundaries!
      });

      if (res.ok) {
        setSuccessMsg(`File '${selectedFile.name}' processed successfully!`);
        fetchFiles(selectedBucket.name);
      } else {
        const err = await res.json();
        setErrorMsg(err.error || "File upload failed. Ensure properties match types constraints.");
      }
    } catch {
      setErrorMsg("Upload timed out or was rejected by server config headers.");
    } finally {
      setUploading(false);
      // Clean input target elements so same file upload triggers change again
      e.target.value = "";
    }
  };

  const handleDeleteFile = async (filePath: string) => {
    if (!selectedBucket) return;
    setErrorMsg(null);
    try {
      const res = await fetch(`${apiUrl}/storage/v1/bucket/${selectedBucket.name}/delete/${filePath}`, {
        method: "DELETE",
      });

      if (res.ok) {
        setSuccessMsg("Object erased from storage.");
        fetchFiles(selectedBucket.name);
      } else {
        const err = await res.json();
        setErrorMsg(err.error || "Access Denied erasing file.");
      }
    } catch {
      setErrorMsg("Network communication failure.");
    }
  };

  const copyUrlToClipboard = (path: string) => {
    const fullUrl = `${window.location.origin}${path}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedLink(path);
    setTimeout(() => setCopiedLink(null), 2000);
  };

  // Convert bytes into human-readable metric descriptions
  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  // Switch visual folder icon based on file formats
  const renderMimeIcon = (mimeType: string) => {
    if (mimeType.startsWith("image/")) return <Image className="h-4.5 w-4.5 text-emerald-500" />;
    if (mimeType.startsWith("video/")) return <Video className="h-4.5 w-4.5 text-amber-500" />;
    return <FileText className="h-4.5 w-4.5 text-indigo-500" />;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6" id="storage-browser-root">
      {/* Sidebar: Buckets checklist */}
      <div className="lg:col-span-1 bg-white border border-slate-200 rounded-xl p-4 flex flex-col gap-4 shadow-xs" id="storage-sidebar">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Object Buckets</span>
          <button
            onClick={() => setIsCreatingBucket(true)}
            className="p-1 px-2.5 rounded bg-amber-50 hover:bg-amber-100 text-amber-600 border border-amber-200 transition-colors text-xs font-semibold flex items-center gap-1"
          >
            <FolderPlus className="h-3 w-3" /> New
          </button>
        </div>

        <div className="space-y-1.5 overflow-y-auto max-h-[350px] flex-1" id="buckets-scroller">
          {buckets.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-4">No active storage buckets initialized.</p>
          ) : (
            buckets.map((buck) => (
              <button
                key={buck.name}
                onClick={() => {
                  setSelectedBucket(buck);
                  setIsCreatingBucket(false);
                }}
                className={`w-full text-left p-3 rounded-lg text-xs font-medium border transition-all flex items-center justify-between ${
                  selectedBucket?.name === buck.name && !isCreatingBucket
                    ? "bg-amber-50/80 text-amber-800 border-amber-200 shadow-2xs"
                    : "bg-slate-50 text-slate-700 border-slate-200/80 hover:bg-slate-100/60"
                }`}
              >
                <div className="flex items-center gap-2">
                  <Folder className={`h-4 w-4 ${selectedBucket?.name === buck.name && !isCreatingBucket ? "text-amber-500 fill-amber-100" : "text-slate-400"}`} />
                  <span className="font-mono">{buck.name}</span>
                </div>
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-semibold border ${
                  buck.is_public ? "bg-emerald-100/60 border-emerald-200 text-emerald-700" : "bg-rose-100/60 border-rose-200 text-rose-700"
                }`}>
                  {buck.is_public ? "Public" : "Private"}
                </span>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Workspace file spreadsheet */}
      <div className="lg:col-span-3 min-h-[400px] flex flex-col gap-4" id="storage-workspace">
        {/* Toast alerts */}
        {errorMsg && (
          <div className="p-3 bg-rose-50 text-rose-800 text-xs rounded-lg border border-rose-200 flex justify-between items-center" id="stor-err">
            <span>{errorMsg}</span>
            <button onClick={() => setErrorMsg(null)} className="hover:text-rose-950 font-bold">&times;</button>
          </div>
        )}
        {successMsg && (
          <div className="p-3 bg-emerald-50 text-emerald-800 text-xs rounded-lg border border-emerald-200 flex justify-between items-center" id="stor-succ">
            <span>{successMsg}</span>
            <button onClick={() => setSuccessMsg(null)} className="hover:text-emerald-950 font-bold">&times;</button>
          </div>
        )}

        {/* 1. CREATING BUCKET SCREEN */}
        {isCreatingBucket ? (
          <form onSubmit={handleCreateBucket} className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4" id="create-bucket-form">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-800">Provision Object Bucket</h3>
                <p className="text-xs text-slate-400">Buckets act as storage directories hosting files, assets, and folders.</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsCreatingBucket(false);
                  if (buckets.length > 0) setSelectedBucket(buckets[0]);
                }}
                className="text-slate-400 hover:text-slate-600 text-xs font-semibold"
              >
                Cancel
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Bucket Name</label>
                <input
                  type="text"
                  placeholder="e.g. avatars, invoices"
                  value={newBucketName}
                  onChange={(e) => setNewBucketName(e.target.value)}
                  className="w-full text-xs font-mono p-2.5 rounded-lg border border-slate-200 focus:outline-amber-500 bg-slate-50"
                  required
                />
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-slate-700 block">Public Bucket</span>
                  <p className="text-[10px] text-slate-400">Allows downloading assets anonymously without valid auth headers.</p>
                </div>
                <input
                  type="checkbox"
                  checked={newBucketPublic}
                  onChange={(e) => setNewBucketPublic(e.target.checked)}
                  className="h-4 h-4 cursor-pointer accent-amber-500"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-slate-900 text-white font-semibold text-xs p-3 rounded-lg flex items-center justify-center gap-1 hover:bg-slate-800 transition-colors"
            >
              Initialize Storage Bucket
            </button>
          </form>
        ) : selectedBucket ? (
          /* 2. FILE BROWSER SCREEN */
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden flex flex-col flex-1" id="storage-file-browser">
            {/* Header banner */}
            <div className="p-4 bg-slate-50 border-b border-slate-150 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-800 font-mono">Bucket: {selectedBucket.name}</h3>
                  <span className={`inline-flex items-center gap-1 text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    selectedBucket.is_public ? "bg-emerald-50 text-emerald-700 border border-emerald-100" : "bg-rose-50 text-rose-700 border border-rose-100"
                  }`}>
                    {selectedBucket.is_public ? <ShieldCheck className="h-2.5 w-2.5" /> : <ShieldAlert className="h-2.5 w-2.5" />}
                    {selectedBucket.is_public ? "Anonymous Read Granted" : "Private Session Only"}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-mono mt-0.5">Created at: {new Date(selectedBucket.created_at).toLocaleString()}</p>
              </div>

              <div className="flex items-center gap-2">
                {/* Real File Input Upload */}
                <label className="cursor-pointer px-3 py-1.5 rounded-lg bg-emerald-600 border border-emerald-700 hover:bg-emerald-700 transition-colors text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm shadow-emerald-50">
                  <UploadCloud className="h-4 w-4" />
                  {uploading ? "Uploading..." : "Upload Asset"}
                  <input
                    type="file"
                    onChange={handleFileUpload}
                    disabled={uploading}
                    className="hidden"
                    accept="image/*,video/*,application/pdf"
                  />
                </label>

                <button
                  onClick={() => handleDeleteBucket(selectedBucket.name)}
                  className="px-3 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-50 text-rose-600 text-xs font-semibold flex items-center gap-1 transition-colors"
                >
                  <Trash2 className="h-4 w-4" /> Drop Bucket
                </button>
              </div>
            </div>

            {/* Constraints notification */}
            <div className="bg-blue-50/50 border-b border-blue-100/50 px-4 py-2 text-[10px] text-slate-500 leading-snug">
              ℹ Files size limit: <span className="font-bold">50MB</span>. Dispatched uploads strictly restricted to MIME types: <span className="font-bold">images, PDFs, or videos</span>.
            </div>

            {/* List Table Sheets */}
            <div className="overflow-x-auto flex-1 h-full min-h-[220px]" id="storage-items-shelf">
              {loadingFiles ? (
                <div className="flex flex-col items-center justify-center p-12 text-slate-400 text-xs text-center">
                  <span className="animate-spin h-5 w-5 border-2 border-slate-300 border-t-amber-500 rounded-full mb-2" />
                  Refreshing upload records...
                </div>
              ) : files.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs max-w-sm mx-auto">
                  <UploadCloud className="h-8 w-8 mx-auto text-slate-300 mb-2" />
                  This storage bucket is empty. Drop valid media uploads inside to populate content directories.
                </div>
              ) : (
                <table className="w-full text-xs text-left border-collapse" id="storage-assets-table">
                  <thead className="bg-slate-50 border-b border-slate-100 font-mono font-medium text-slate-400 uppercase text-[9px] tracking-wider select-none">
                    <tr>
                      <th className="px-4 py-2.5">Asset Path Name</th>
                      <th className="px-4 py-2.5">File Size</th>
                      <th className="px-4 py-2.5">MIME Category</th>
                      <th className="px-4 py-2.5">Modified Timeline</th>
                      <th className="px-4 py-2.5 text-center">Key actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {files.map((f, idx) => {
                      const downloadUrl = `/storage/v1/bucket/${selectedBucket.name}/download/${f.path}`;
                      return (
                        <tr key={idx} className="hover:bg-slate-50/40 select-all">
                          <td className="px-4 py-2 font-semibold text-slate-700 flex items-center gap-2">
                            {renderMimeIcon(f.mimeType)}
                            <span className="truncate max-w-[150px]">{f.path}</span>
                          </td>
                          <td className="px-4 py-2 text-slate-500">
                            {formatBytes(f.size)}
                          </td>
                          <td className="px-4 py-2 text-slate-400 font-sans text-[10px]">
                            {f.mimeType}
                          </td>
                          <td className="px-4 py-2 text-slate-500 font-sans text-[10px]">
                            {new Date(f.updatedAt).toLocaleDateString()} at {new Date(f.updatedAt).toLocaleTimeString()}
                          </td>
                          <td className="px-4 py-2 text-center space-x-1">
                            {/* Copy Public URL Link */}
                            <button
                              onClick={() => copyUrlToClipboard(downloadUrl)}
                              className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded cursor-pointer shrink-0 inline-block align-middle"
                              title="Copy URL location reference"
                            >
                              {copiedLink === downloadUrl ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                            </button>

                            {/* Download local trigger */}
                            <a
                              href={downloadUrl}
                              download={f.path}
                              className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded inline-block align-middle"
                              title="Download Asset"
                            >
                              <Download className="h-3.5 w-3.5" />
                            </a>

                            {/* Delete specific files */}
                            <button
                              onClick={() => handleDeleteFile(f.path)}
                              className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded cursor-pointer inline-block align-middle"
                              title="Delete specific media object"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-400 text-xs shadow-sm">
            Select or initialize a storage bucket directory to upload documents and photos.
          </div>
        )}
      </div>
    </div>
  );
}
