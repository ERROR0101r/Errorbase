import React, { useState } from "react";
import { Terminal, Play, CircleAlert, CheckCircle2, History, HelpCircle } from "lucide-react";

interface SqlConsoleProps {
  onRefreshAll: () => void;
  executeRawSql: (sql: string) => Promise<{ success: boolean; data?: any[]; affectedRows?: number; schemaChanged?: boolean; error?: string }>;
}

export default function SqlConsoleTab({ onRefreshAll, executeRawSql }: SqlConsoleProps) {
  const [sqlQuery, setSqlQuery] = useState(`-- Welcome to ErrorBase SQL Query Workspace
-- Write valid queries or use the templates below to test the database engine.
-- Tables available: todos, profiles

SELECT * FROM todos ORDER BY completed ASC;`);

  const [executing, setExecuting] = useState(false);
  const [resultData, setResultData] = useState<any[] | null>(null);
  const [affectedRows, setAffectedRows] = useState<number | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<string | null>(null);
  const [queryHistory, setQueryHistory] = useState<string[]>([]);

  // Pre-configured snippets for ease of learning
  const snippets = [
    {
      label: "Select Todos",
      sql: "SELECT * FROM todos ORDER BY created_at DESC;",
    },
    {
      label: "Insert Todo",
      sql: "INSERT INTO todos (title, completed, owner_id) VALUES ('Connect to ErrorBase WebSockets', false, 'usr-demo123');",
    },
    {
      label: "Select User Profiles",
      sql: "SELECT * FROM profiles ORDER BY full_name ASC;",
    },
    {
      label: "Create Products Table",
      sql: `CREATE TABLE products (
  id TEXT PRIMARY KEY,
  name TEXT,
  price INTEGER,
  active BOOLEAN
);`,
    },
    {
      label: "Insert Sample Product",
      sql: "INSERT INTO products (name, price, active) VALUES ('MacBook Pro M4', 2499, true);",
    },
    {
      label: "Drop Products Table",
      sql: "DROP TABLE products;",
    },
  ];

  const handleExecute = async () => {
    if (!sqlQuery.trim()) return;
    setExecuting(true);
    setResultData(null);
    setAffectedRows(null);
    setErrorMsg(null);
    setSuccessInfo(null);

    // Filter commenting tags
    const lines = sqlQuery.split("\n");
    const activeLines = lines.filter((l) => !l.trim().startsWith("--") && !l.trim().startsWith("//"));
    const finalSql = activeLines.join(" ").trim();

    if (!finalSql) {
      setErrorMsg("Query empty. Please write valid SQLite execution code.");
      setExecuting(false);
      return;
    }

    try {
      const resp = await executeRawSql(finalSql);
      // Append query log history
      setQueryHistory((prev) => [sqlQuery, ...prev.slice(0, 9)]);

      if (resp.success) {
        if (resp.data && resp.data.length > 0) {
          setResultData(resp.data);
          setSuccessInfo(`Selected ${resp.data.length} records successfully.`);
        } else {
          setAffectedRows(resp.affectedRows !== undefined ? resp.affectedRows : 0);
          setSuccessInfo("Statement executed successfully with no returned rows.");
        }

        if (resp.schemaChanged) {
          // Refresh global schemas
          onRefreshAll();
        }
      } else {
        setErrorMsg(resp.error || "Execution terminated unexpectedly.");
      }
    } catch (err: any) {
      setErrorMsg(err.message || "Network failure invoking SQL execution.");
    } finally {
      setExecuting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="sql-console-workspace-root">
      {/* Code Editor and Suggestions */}
      <div className="lg:col-span-2 flex flex-col gap-4" id="sql-editor-panel">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Terminal className="h-5 w-5 text-emerald-500" />
              <div>
                <h3 className="text-sm font-bold text-slate-800">Direct SQL Command Editor</h3>
                <p className="text-[10px] text-slate-400">Directly alter database tables and columns executing mock SQL queries.</p>
              </div>
            </div>
            <button
              onClick={handleExecute}
              disabled={executing}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white disabled:bg-slate-400 transition-colors font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm shadow-emerald-100"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              {executing ? "Executing..." : "Run Query"}
            </button>
          </div>

          {/* Text Area Code Editor */}
          <div className="relative font-mono text-[11px]" id="sql-code-area-container">
            <textarea
              value={sqlQuery}
              onChange={(e) => setSqlQuery(e.target.value)}
              placeholder="e.g. SELECT * FROM todos ORDER BY id DESC"
              className="w-full h-56 bg-slate-900 text-emerald-400 p-4 rounded-xl border border-slate-950 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono select-text"
              spellCheck="false"
            />
          </div>

          {/* Snippet Grid */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Suggested Query Templates</span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {snippets.map((snip, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => setSqlQuery(snip.sql)}
                  className="text-left font-mono border border-slate-200/80 bg-slate-50 hover:bg-slate-100 transition-all p-2 rounded text-[10px] text-slate-600 font-medium truncate block cursor-pointer"
                  title={snip.sql}
                >
                  {snip.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Output / Results Console */}
      <div className="lg:col-span-1 bg-white border border-slate-200 rounded-xl p-4 flex flex-col gap-4 shadow-xs" id="sql-output-panel">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Statement Result Console</span>

        {/* Feedback indicators */}
        <div className="space-y-3" id="sql-logs-feedback">
          {errorMsg && (
            <div className="p-3 bg-rose-50 text-rose-800 rounded-lg border border-rose-150 flex items-start gap-2.5 text-xs">
              <CircleAlert className="h-4.5 w-4.5 text-rose-600 mt-0.5 flex-shrink-0" />
              <div>
                <span className="font-bold">SQL Execution Failed:</span>
                <p className="mt-0.5 font-mono text-[10px] leading-snug break-words">{errorMsg}</p>
              </div>
            </div>
          )}

          {successInfo && !errorMsg && (
            <div className="p-3 bg-emerald-50 text-emerald-800 rounded-lg border border-emerald-150 flex items-start gap-2.5 text-xs">
              <CheckCircle2 className="h-4.5 w-4.5 text-emerald-600 mt-0.5 flex-shrink-0" />
              <div>
                <span className="font-bold">Success:</span>
                <p className="mt-0.5 text-[10px]">{successInfo}</p>
                {affectedRows !== null && (
                  <p className="font-mono text-[10px] mt-1 text-emerald-600">Affected Row count: {affectedRows}</p>
                )}
              </div>
            </div>
          )}

          {!errorMsg && !successInfo && (
            <div className="p-8 border border-dashed border-slate-200 rounded-lg text-center text-slate-400 text-xs">
              <HelpCircle className="h-8 w-8 mx-auto text-slate-300 mb-1.5" />
              Execute a valid SQL query script to review compiled spreadsheet grids.
            </div>
          )}
        </div>

        {/* Dynamic Returned Rows Drawer */}
        {resultData && resultData.length > 0 && (
          <div className="flex-1 flex flex-col min-h-[160px] overflow-hidden" id="sql-return-drawer">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
              Data Sheet ({resultData.length} records found)
            </span>
            <div className="border border-slate-200 rounded-lg overflow-auto max-h-[220px] flex-1 text-[10px]" id="sql-return-rows-sheet">
              <table className="w-full text-left font-mono">
                <thead className="bg-slate-50 border-b border-slate-100 select-none uppercase text-slate-500 tracking-tighter">
                  <tr>
                    {Object.keys(resultData[0]).map((key) => (
                      <th key={key} className="px-2 py-1.5 border-r border-slate-200">
                        {key}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {resultData.map((row, rowIdx) => (
                    <tr key={rowIdx} className="hover:bg-slate-50">
                      {Object.values(row).map((val: any, colIdx) => (
                        <td key={colIdx} className="px-2 py-1 border-r border-slate-100 truncate max-w-[120px]" title={String(val)}>
                          {val !== null && val !== undefined ? String(val) : "NULL"}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* History tracking */}
        {queryHistory.length > 0 && (
          <div className="border-t border-slate-100 pt-3" id="sql-history-subcard">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 mb-2">
              <History className="h-3 w-3" /> Historical Queries
            </span>
            <div className="space-y-1 overflow-y-auto max-h-[80px]" id="sql-history-logs">
              {queryHistory.map((hist, idx) => (
                <button
                  key={idx}
                  onClick={() => setSqlQuery(hist)}
                  className="w-full text-left font-mono text-[9px] bg-slate-50 border border-slate-100 hover:bg-slate-100 hover:border-slate-200 p-1 rounded text-slate-500 truncate block cursor-pointer transition-colors"
                >
                  {hist.replace(/\s+/g, " ")}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
