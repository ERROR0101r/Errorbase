import React, { useState, useEffect } from "react";
import { TableSchema, Column, RlsPolicy } from "../types.ts";
import { Database, Plus, Trash2, Key, Shield, ShieldOff, Search, Edit2, Check, X, Eye, Play, Sparkles } from "lucide-react";

interface TableBrowserProps {
  tables: TableSchema[];
  onRefresh: () => void;
  executeRawSql: (sql: string) => Promise<{ success: boolean; data?: any[]; error?: string }>;
  apiUrl: string;
}

export default function TableBrowserTab({ tables, onRefresh, executeRawSql, apiUrl }: TableBrowserProps) {
  const [selectedTable, setSelectedTable] = useState<TableSchema | null>(null);
  const [rows, setRows] = useState<any[]>([]);
  const [loadingRows, setLoadingRows] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Schema creation states
  const [isCreatingTable, setIsCreatingTable] = useState(false);
  const [newTableName, setNewTableName] = useState("");
  const [newTableRlsEnabled, setNewTableRlsEnabled] = useState(true);
  const [newTablePolicy, setNewTablePolicy] = useState<RlsPolicy>("owner_only");
  const [newTableColumns, setNewTableColumns] = useState<Column[]>([
    { name: "id", type: "text", is_primary: true },
    { name: "created_at", type: "timestamp", is_primary: false },
  ]);

  // Row operations states
  const [isAddingRow, setIsAddingRow] = useState(false);
  const [newRowData, setNewRowData] = useState<Record<string, any>>({});
  const [editingRowId, setEditingRowId] = useState<string | null>(null);
  const [editingRowData, setEditingRowData] = useState<Record<string, any>>({});

  // Auto-select first table if none selected
  useEffect(() => {
    if (tables.length > 0 && !selectedTable) {
      setSelectedTable(tables[0]);
    }
  }, [tables, selectedTable]);

  // Load rows when selected table changes
  useEffect(() => {
    if (selectedTable) {
      fetchRows(selectedTable.name);
    } else {
      setRows([]);
    }
  }, [selectedTable]);

  const fetchRows = async (tableName: string) => {
    setLoadingRows(true);
    setErrorMsg(null);
    try {
      const res = await fetch(`${apiUrl}/api/rest/v1/${tableName}`);
      if (res.ok) {
        const data = await res.json();
        setRows(data);
      } else {
        const err = await res.json();
        setErrorMsg(err.error || `Failed to fetch records for table '${tableName}'.`);
      }
    } catch (err) {
      setErrorMsg("Failed to reach server to retrieve database records.");
    } finally {
      setLoadingRows(false);
    }
  };

  // Create Table handler
  const handleCreateTable = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const name = newTableName.trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
    if (!name) {
      setErrorMsg("Table name must contain valid lowercase alphanumeric letters.");
      return;
    }

    if (newTableColumns.length === 0) {
      setErrorMsg("A database table requires at least 1 column definition.");
      return;
    }

    // Build standard SQL schema CREATE string
    const colDefs = newTableColumns.map((col) => {
      let typeStr = "TEXT";
      if (col.type === "number") typeStr = "INTEGER";
      if (col.type === "boolean") typeStr = "BOOLEAN";
      if (col.type === "timestamp") typeStr = "TIMESTAMP";
      
      const pkStr = col.is_primary ? " PRIMARY KEY" : "";
      return `${col.name} ${typeStr}${pkStr}`;
    }).join(", ");

    const sqlStatement = `CREATE TABLE ${name} (${colDefs})`;

    try {
      // Execute the SQL creation command to generate schema
      const result = await executeRawSql(sqlStatement);
      if (result.success) {
        // Apply RLS policy configuration if requested
        if (newTableRlsEnabled) {
          const rlsSql = `UPDATE_POLICY_CONFIG '${name}' ENABLED '${newTablePolicy}'`;
          // We can call server policy set API directly in background
          await fetch(`${apiUrl}/api/rest/v1/${name}/policy`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ rls_enabled: true, policy: newTablePolicy }),
          }).catch(() => {});
        }

        setSuccessMsg(`Database table '${name}' constructed successfully!`);
        setIsCreatingTable(false);
        setNewTableName("");
        setNewTableColumns([
          { name: "id", type: "text", is_primary: true },
          { name: "created_at", type: "timestamp", is_primary: false },
        ]);
        onRefresh();
      } else {
        setErrorMsg(result.error || "Execution failed.");
      }
    } catch (e: any) {
      setErrorMsg(e.message || "An error occurred constructing table index.");
    }
  };

  // Add Column to schema draft
  const addColumnDraft = () => {
    const colName = `col_${newTableColumns.length + 1}`;
    setNewTableColumns([...newTableColumns, { name: colName, type: "text", is_primary: false }]);
  };

  // Remove Column from schema draft
  const removeColumnDraft = (idx: number) => {
    setNewTableColumns(newTableColumns.filter((_, i) => i !== idx));
  };

  // Edit Column draft
  const updateColumnDraft = (idx: number, field: keyof Column, value: any) => {
    const updated = [...newTableColumns];
    updated[idx] = { ...updated[idx], [field]: value };
    setNewTableColumns(updated);
  };

  // Delete Table Handler
  const handleDeleteTable = async (tableName: string) => {
    if (!confirm(`Are you absolutely sure you want to drop standard table '${tableName}'? This cleanses all rows eternally!`)) return;
    setErrorMsg(null);
    try {
      const result = await executeRawSql(`DROP TABLE ${tableName}`);
      if (result.success) {
        setSuccessMsg(`Table '${tableName}' has been dropped successfully.`);
        setSelectedTable(null);
        onRefresh();
      } else {
        setErrorMsg(result.error || "Failed to drop storage container table.");
      }
    } catch (err) {
      setErrorMsg("Failed to transmit query to server.");
    }
  };

  // Delete Row Handler
  const handleDeleteRow = async (row: any) => {
    if (!selectedTable) return;
    setErrorMsg(null);

    const pkCol = selectedTable.columns.find((c) => c.is_primary) || selectedTable.columns[0];
    const pkVal = row[pkCol.name];

    try {
      const res = await fetch(`${apiUrl}/api/rest/v1/${selectedTable.name}?${pkCol.name}=eq.${pkVal}`, {
        method: "DELETE",
      });

      if (res.ok) {
        setSuccessMsg("Database record deleted successfully.");
        fetchRows(selectedTable.name);
      } else {
        const err = await res.json();
        setErrorMsg(err.error || "Failed to finalize database deletion.");
      }
    } catch (e) {
      setErrorMsg("Network failure occurred during transmission.");
    }
  };

  // Add Row Handler
  const handleAddRow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTable) return;
    setErrorMsg(null);

    try {
      const res = await fetch(`${apiUrl}/api/rest/v1/${selectedTable.name}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newRowData),
      });

      if (res.ok) {
        setSuccessMsg("Row successfully appended in database.");
        setIsAddingRow(false);
        setNewRowData({});
        fetchRows(selectedTable.name);
      } else {
        const err = await res.json();
        setErrorMsg(err.error || "Failed to submit row data.");
      }
    } catch (e) {
      setErrorMsg("Network failure during insert request.");
    }
  };

  // Inline Row Edit trigger
  const startEditingRow = (row: any) => {
    if (!selectedTable) return;
    const pkCol = selectedTable.columns.find((c) => c.is_primary) || selectedTable.columns[0];
    setEditingRowId(row[pkCol.name]);
    setEditingRowData({ ...row });
  };

  // Submit inline Row correction
  const submitRowEdit = async (row: any) => {
    if (!selectedTable) return;
    setErrorMsg(null);

    const pkCol = selectedTable.columns.find((c) => c.is_primary) || selectedTable.columns[0];
    const pkVal = row[pkCol.name];

    // Exclude primary key from patch body
    const patchBody = { ...editingRowData };
    delete patchBody[pkCol.name];

    try {
      const res = await fetch(`${apiUrl}/api/rest/v1/${selectedTable.name}?${pkCol.name}=eq.${pkVal}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patchBody),
      });

      if (res.ok) {
        setSuccessMsg("Row context updated successfully.");
        setEditingRowId(null);
        fetchRows(selectedTable.name);
      } else {
        const err = await res.json();
        setErrorMsg(err.error || "Row update rejected by server RLS constraints.");
      }
    } catch (e) {
      setErrorMsg("Network error trying to apply row corrections.");
    }
  };

  // Policy formatter helper
  const policyLabels: Record<RlsPolicy, string> = {
    public_all: "Public (Full Access)",
    public_read_auth_write: "Public Read, Auth Write",
    owner_only: "Owner Only (Strict RLS)",
    private: "Private (Admin Only)",
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6" id="table-browser-root">
      {/* Sidebar: Tables List */}
      <div className="lg:col-span-1 bg-white border border-slate-200 rounded-xl p-4 flex flex-col gap-4 shadow-xs" id="table-sidebar">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Database Tables</span>
          <button
            onClick={() => {
              setIsCreatingTable(true);
              setSelectedTable(null);
            }}
            className="p-1 px-2.5 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-600 transition-colors text-xs font-semibold flex items-center gap-1 border border-emerald-200"
          >
            <Plus className="h-3 w-3" /> New
          </button>
        </div>

        <div className="space-y-1.5 overflow-y-auto max-h-[450px] flex-1" id="sidebar-tables-scroller">
          {tables.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-4">No custom tables initialized yet.</p>
          ) : (
            tables.map((tbl) => (
              <button
                key={tbl.name}
                onClick={() => {
                  setSelectedTable(tbl);
                  setIsCreatingTable(false);
                }}
                className={`w-full text-left p-3 rounded-lg text-xs font-medium border transition-all flex items-center justify-between ${
                  selectedTable?.name === tbl.name && !isCreatingTable
                    ? "bg-emerald-50 text-emerald-800 border-emerald-200 shadow-2xs"
                    : "bg-slate-50 text-slate-700 border-slate-200/80 hover:bg-slate-100/60"
                }`}
              >
                <div className="flex items-center gap-2">
                  <Database className={`h-3.5 w-3.5 ${selectedTable?.name === tbl.name && !isCreatingTable ? "text-emerald-600" : "text-slate-400"}`} />
                  <span className="font-mono">{tbl.name}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200/60 text-slate-500 font-mono">
                    {tbl.columns.length} cols
                  </span>
                  {tbl.rls_enabled ? (
                    <Shield className="h-3 w-3 text-emerald-600" title="RLS Engaged" />
                  ) : (
                    <ShieldOff className="h-3 w-3 text-slate-300" title="RLS Discharged" />
                  )}
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="lg:col-span-3 min-h-[400px] flex flex-col gap-4" id="table-workspace">
        {/* Messages */}
        {errorMsg && (
          <div className="p-3.5 bg-rose-50 text-rose-800 text-xs rounded-lg border border-rose-200 flex justify-between items-center animate-fade-in" id="error-alert">
            <span>{errorMsg}</span>
            <button onClick={() => setErrorMsg(null)} className="hover:text-rose-950 font-bold px-1 text-sm">&times;</button>
          </div>
        )}
        {successMsg && (
          <div className="p-3.5 bg-emerald-50 text-emerald-800 text-xs rounded-lg border border-emerald-200 flex justify-between items-center animate-fade-in" id="success-alert">
            <span>{successMsg}</span>
            <button onClick={() => setSuccessMsg(null)} className="hover:text-emerald-950 font-bold px-1 text-sm">&times;</button>
          </div>
        )}

        {/* 1. SCHEMA CREATION FLOW */}
        {isCreatingTable ? (
          <form onSubmit={handleCreateTable} className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6" id="create-table-view">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                  <Sparkles className="text-emerald-500 h-5 w-5" />
                  Define New Table SQL Schema
                </h3>
                <p className="text-xs text-slate-400">Construct an automatic PostgREST CRUD endpoint indices instantly.</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsCreatingTable(false);
                  if (tables.length > 0) setSelectedTable(tables[0]);
                }}
                className="text-slate-400 hover:text-slate-600 text-xs font-semibold px-2"
              >
                Cancel
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-tighter mb-1.5">Table Title</label>
                <input
                  type="text"
                  placeholder="e.g. products, customers"
                  value={newTableName}
                  onChange={(e) => setNewTableName(e.target.value)}
                  className="w-full text-xs font-mono p-2.5 rounded-lg border border-slate-200 focus:outline-emerald-500 bg-slate-50"
                  required
                />
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex flex-col justify-center">
                <div className="flex items-center justify-between pb-1.5">
                  <span className="text-xs font-semibold text-slate-600">Row Level Security (RLS)</span>
                  <input
                    type="checkbox"
                    checked={newTableRlsEnabled}
                    onChange={(e) => setNewTableRlsEnabled(e.target.checked)}
                    className="h-4 w-4 accent-emerald-500 cursor-pointer"
                  />
                </div>
                {newTableRlsEnabled && (
                  <select
                    value={newTablePolicy}
                    onChange={(e) => setNewTablePolicy(e.target.value as RlsPolicy)}
                    className="w-full text-xs p-1.5 rounded border border-slate-200 bg-white"
                  >
                    <option value="owner_only">Owner Only (where owner_id = active userID)</option>
                    <option value="public_read_auth_write">Public Read, authenticated Writer</option>
                    <option value="public_all">Public (Anonymous Read + Write)</option>
                    <option value="private">Private (Administrators Only)</option>
                  </select>
                )}
              </div>
            </div>

            {/* Column definitions list */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-600 uppercase tracking-tighter">Columns Setup</label>
                <button
                  type="button"
                  onClick={addColumnDraft}
                  className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
                >
                  <Plus className="h-3 w-3" /> Add Column
                </button>
              </div>

              <div className="border border-slate-100 rounded-lg overflow-hidden space-y-1.5 p-3 bg-slate-50" id="columns-draft-sheet">
                {newTableColumns.map((col, idx) => (
                  <div key={idx} className="flex flex-wrap items-center gap-2 bg-white p-2 rounded border border-slate-200/60 shadow-3xs">
                    <input
                      type="text"
                      placeholder="Column name"
                      value={col.name}
                      onChange={(e) => updateColumnDraft(idx, "name", e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))}
                      className="text-xs font-mono p-1.5 rounded border border-slate-200 max-w-[150px]"
                      disabled={col.is_primary} // PK is protected usually
                      required
                    />
                    <select
                      value={col.type}
                      onChange={(e) => updateColumnDraft(idx, "type", e.target.value)}
                      className="text-xs p-1.5 rounded border border-slate-200"
                      disabled={col.is_primary}
                    >
                      <option value="text">text / uuid</option>
                      <option value="number">number / integer</option>
                      <option value="boolean">boolean</option>
                      <option value="timestamp">timestamp (UTC)</option>
                    </select>

                    <label className="flex items-center gap-1 text-[10px] font-semibold text-slate-500 select-none cursor-pointer">
                      <input
                        type="checkbox"
                        checked={col.is_primary}
                        onChange={(e) => {
                          // Clean others PK
                          const cleaned = newTableColumns.map((c, i) => ({ ...c, is_primary: i === idx ? e.target.checked : false }));
                          setNewTableColumns(cleaned);
                        }}
                        className="accent-emerald-500 h-3 w-3"
                      />
                      Primary Key
                    </label>

                    {!col.is_primary && (
                      <button
                        type="button"
                        onClick={() => removeColumnDraft(idx)}
                        className="ml-auto text-slate-400 hover:text-rose-600 p-1"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs p-3 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-xs transition-colors"
            >
              <Play className="h-3 w-3 shadow-sm fill-current" /> Initialize Table SQLite Schema
            </button>
          </form>
        ) : selectedTable ? (
          /* 2. SPREADSHEET TABLE BROWSER & CRUD GRID */
          <div className="bg-white border border-slate-200 rounded-xl flex flex-col flex-1 shadow-sm overflow-hidden" id="table-crud-grid-view">
            {/* Header metadata definitions */}
            <div className="p-4 bg-slate-50 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-slate-800 font-mono">{selectedTable.name}</h3>
                  <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    selectedTable.rls_enabled ? "bg-emerald-100 text-emerald-800 border border-emerald-200" : "bg-amber-100 text-amber-800 border border-amber-200"
                  }`}>
                    {selectedTable.rls_enabled ? <Shield className="h-2.5 w-2.5" /> : <ShieldOff className="h-2.5 w-2.5" />}
                    RLS: {selectedTable.rls_enabled ? "Engaged" : "Off"}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Policy: <span className="font-semibold">{policyLabels[selectedTable.policy] || selectedTable.policy}</span>
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAddingRow(true)}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-950 text-white hover:bg-slate-800 transition-colors text-xs font-semibold flex items-center gap-1"
                >
                  <Plus className="h-3.5 w-3.5" /> Insert Row
                </button>
                <button
                  onClick={() => handleDeleteTable(selectedTable.name)}
                  className="px-3 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-50 text-rose-600 transition-colors text-xs font-semibold flex items-center gap-1"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Drop Table
                </button>
              </div>
            </div>

            {/* Grid interactive search and controls */}
            <div className="p-3 border-b border-slate-100 flex items-center justify-between bg-white text-xs gap-3">
              <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 max-w-sm flex-1">
                <Search className="h-3.5 w-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Real-time client search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-transparent focus:outline-none text-xs w-full font-sans text-slate-600"
                />
              </div>
              <button
                onClick={() => fetchRows(selectedTable.name)}
                className="text-xs text-slate-500 underline font-semibold hover:text-slate-800 cursor-pointer"
              >
                Refresh Records
              </button>
            </div>

            {/* Spreadsheet interactive data sheet canvas */}
            <div className="overflow-x-auto select-text relative flex-1" id="grid-spreadsheet-scroller">
              {loadingRows ? (
                <div className="flex flex-col items-center justify-center p-12 text-slate-400 text-xs">
                  <span className="animate-spin h-5 w-5 border-2 border-slate-300 border-t-emerald-500 rounded-full mb-2" />
                  Fetching records from API...
                </div>
              ) : rows.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs">
                  No records stored in this table. Double click 'Insert Row' to populate it.
                </div>
              ) : (
                <table className="w-full text-xs text-left border-collapse" id="data-sheet-table">
                  <thead className="bg-slate-50 border-b border-slate-200 font-mono font-medium text-slate-500 uppercase text-[10px] tracking-wider select-none sticky top-0">
                    <tr>
                      {selectedTable.columns.map((c) => (
                        <th key={c.name} className="px-4 py-3 border-r border-slate-200/85">
                          {c.name} {c.is_primary && "🔑"}
                        </th>
                      ))}
                      <th className="px-4 py-3 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {rows
                      .filter((row) =>
                        Object.values(row).some((val) =>
                          String(val).toLowerCase().includes(searchQuery.toLowerCase())
                        )
                      )
                      .map((row, rowIdx) => {
                        const pkCol = selectedTable.columns.find((c) => c.is_primary) || selectedTable.columns[0];
                        const rowPkValue = row[pkCol.name];
                        const isEditing = editingRowId === rowPkValue;

                        return (
                          <tr key={rowIdx} className="hover:bg-slate-50/50 group select-all">
                            {selectedTable.columns.map((col) => (
                              <td key={col.name} className="px-4 py-2 border-r border-slate-100 align-middle">
                                {isEditing ? (
                                  col.type === "boolean" ? (
                                    <input
                                      type="checkbox"
                                      checked={!!editingRowData[col.name]}
                                      onChange={(e) => setEditingRowData({ ...editingRowData, [col.name]: e.target.checked })}
                                      className="accent-emerald-500"
                                    />
                                  ) : col.type === "number" ? (
                                    <input
                                      type="number"
                                      value={editingRowData[col.name] !== undefined ? editingRowData[col.name] : ""}
                                      onChange={(e) => setEditingRowData({ ...editingRowData, [col.name]: Number(e.target.value) })}
                                      className="border border-slate-300 p-1 rounded font-mono text-xs w-full max-w-[120px] focus:outline-emerald-500 bg-white"
                                      disabled={col.is_primary}
                                    />
                                  ) : (
                                    <input
                                      type="text"
                                      value={editingRowData[col.name] !== undefined ? editingRowData[col.name] : ""}
                                      onChange={(e) => setEditingRowData({ ...editingRowData, [col.name]: e.target.value })}
                                      className="border border-slate-300 p-1 rounded font-mono text-xs w-full focus:outline-emerald-500 bg-white"
                                      disabled={col.is_primary}
                                    />
                                  )
                                ) : col.type === "boolean" ? (
                                  <span className={`inline-flex px-1.5 py-0.5 rounded text-[10px] font-bold tracking-tight border ${
                                    row[col.name] ? "bg-emerald-50 text-emerald-700 border-emerald-100" : "bg-slate-100 text-slate-500 border-slate-200"
                                  }`}>
                                    {row[col.name] ? "TRUE" : "FALSE"}
                                  </span>
                                ) : (
                                  <span className="truncate block max-w-[200px]" title={String(row[col.name])}>
                                    {row[col.name] !== null && row[col.name] !== undefined ? String(row[col.name]) : "NULL"}
                                  </span>
                                )}
                              </td>
                            ))}
                            <td className="px-4 py-2 text-center align-middle space-x-1.5 opacity-90 group-hover:opacity-100 transition-opacity">
                              {isEditing ? (
                                <>
                                  <button
                                    onClick={() => submitRowEdit(row)}
                                    className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                                    title="Save modification"
                                  >
                                    <Check className="h-3.5 w-3.5" />
                                  </button>
                                  <button
                                    onClick={() => setEditingRowId(null)}
                                    className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                                    title="Cancel"
                                  >
                                    <X className="h-3.5 w-3.5" />
                                  </button>
                                </>
                              ) : (
                                <>
                                  <button
                                    onClick={() => startEditingRow(row)}
                                    className="p-1 text-slate-500 hover:text-emerald-600 hover:bg-slate-100/80 rounded transition-all"
                                    title="Edit Row Cells"
                                  >
                                    <Edit2 className="h-3.5 w-3.5" />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteRow(row)}
                                    className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-all"
                                    title="Erase Database Record"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-400 text-xs shadow-sm shadow-slate-100/40">
            Create a database table on the left workspace panel to browse record sheets.
          </div>
        )}
      </div>

      {/* 3. ADDING ROW DIALOG / MODAL PANEL */}
      {isAddingRow && selectedTable && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 animate-fade-in" id="add-row-modal">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-md w-full p-6 space-y-4 animate-scale-up">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <span className="text-sm font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-tighter">
                <Database className="h-4 w-4 text-emerald-500" /> Insert Row: {selectedTable.name}
              </span>
              <button onClick={() => setIsAddingRow(false)} className="text-slate-400 hover:text-slate-600 text-lg font-bold">&times;</button>
            </div>

            <form onSubmit={handleAddRow} className="space-y-4 text-xs font-mono">
              {selectedTable.columns.map((col) => (
                <div key={col.name} className="space-y-1">
                  <label className="block text-[11px] uppercase tracking-wider font-semibold text-slate-500">
                    {col.name} {col.is_primary && "🔑 (Optional)"}
                  </label>

                  {col.type === "boolean" ? (
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={!!newRowData[col.name]}
                        onChange={(e) => setNewRowData({ ...newRowData, [col.name]: e.target.checked })}
                        className="h-4 w-4 accent-emerald-500 cursor-pointer"
                      />
                      <span className="text-[11px] text-slate-500">True / False</span>
                    </div>
                  ) : col.type === "number" ? (
                    <input
                      type="number"
                      placeholder="e.g. 100"
                      onChange={(e) => setNewRowData({ ...newRowData, [col.name]: Number(e.target.value) })}
                      className="w-full border border-slate-200 p-2 rounded-lg bg-slate-50 font-mono text-xs focus:outline-emerald-500"
                    />
                  ) : col.type === "timestamp" ? (
                    <input
                      type="text"
                      placeholder="Leave empty for current timestamp"
                      onChange={(e) => setNewRowData({ ...newRowData, [col.name]: e.target.value })}
                      className="w-full border border-slate-200 p-2 rounded-lg bg-slate-50 font-mono text-xs focus:outline-emerald-500"
                    />
                  ) : (
                    <input
                      type="text"
                      placeholder={`Valued input...`}
                      onChange={(e) => setNewRowData({ ...newRowData, [col.name]: e.target.value })}
                      className="w-full border border-slate-200 p-2 rounded-lg bg-slate-50 font-mono text-xs focus:outline-emerald-500"
                    />
                  )}
                </div>
              ))}

              <button
                type="submit"
                className="w-full bg-slate-900 border border-slate-950 p-2.5 rounded-lg text-white font-semibold text-xs mt-4 hover:bg-slate-800 cursor-pointer text-center"
              >
                Insert Record
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
