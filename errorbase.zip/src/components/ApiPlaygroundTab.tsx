import React, { useState, useEffect } from "react";
import { TableSchema } from "../types.ts";
import { Terminal, Copy, Check, Play, FileJson, AlertCircle } from "lucide-react";

interface ApiPlaygroundProps {
  tables: TableSchema[];
  apiUrl: string;
}

export default function ApiPlaygroundTab({ tables, apiUrl }: ApiPlaygroundProps) {
  const [selectedTable, setSelectedTable] = useState<TableSchema | null>(null);
  const [activeMethod, setActiveMethod] = useState<"GET" | "POST" | "DELETE">("GET");
  const [queryParam, setQueryParam] = useState("");
  const [postBodyJson, setPostBodyJson] = useState("");
  const [copiedLabel, setCopiedLabel] = useState<string | null>(null);

  // Playground Execution State
  const [executing, setExecuting] = useState(false);
  const [responseCode, setResponseCode] = useState<number | null>(null);
  const [responseHeaders, setResponseHeaders] = useState<string | null>(null);
  const [responsePayload, setResponsePayload] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (tables.length > 0 && !selectedTable) {
      setSelectedTable(tables[0]);
    }
  }, [tables, selectedTable]);

  // Re-fill body template based on selected table columns
  useEffect(() => {
    if (selectedTable) {
      const template: Record<string, any> = {};
      for (const col of selectedTable.columns) {
        if (col.is_primary) continue;
        if (col.type === "number") template[col.name] = 10;
        else if (col.type === "boolean") template[col.name] = false;
        else if (col.type === "timestamp") template[col.name] = new Date().toISOString();
        else template[col.name] = "value_here";
      }
      setPostBodyJson(JSON.stringify(template, null, 2));

      // Reset query param template
      const pkCol = selectedTable.columns.find((c) => c.is_primary) || selectedTable.columns[0];
      setQueryParam(`?limit=5`);
    }
  }, [selectedTable]);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLabel(label);
    setTimeout(() => setCopiedLabel(null), 2000);
  };

  const executePlaygroundRequest = async () => {
    if (!selectedTable) return;
    setExecuting(true);
    setResponseCode(null);
    setResponseHeaders(null);
    setResponsePayload(null);
    setErrorMessage(null);

    const baseUrl = `${apiUrl}/api/rest/v1/${selectedTable.name}`;
    const targetUrl = activeMethod === "GET" ? `${baseUrl}${queryParam}` : activeMethod === "DELETE" ? `${baseUrl}${queryParam}` : baseUrl;

    const requestOptions: RequestInit = {
      method: activeMethod,
      headers: { "Content-Type": "application/json" },
    };

    if (activeMethod === "POST") {
      try {
        JSON.parse(postBodyJson); // validate
        requestOptions.body = postBodyJson;
      } catch (e) {
        setErrorMessage("Request payload is not a valid JSON structure.");
        setExecuting(false);
        return;
      }
    }

    try {
      const res = await fetch(targetUrl, requestOptions);
      setResponseCode(res.status);
      
      // Parse response headers helper representation
      let headersStr = `Status: ${res.status} ${res.statusText}\n`;
      res.headers.forEach((val, key) => {
        headersStr += `${key}: ${val}\n`;
      });
      setResponseHeaders(headersStr);

      const data = await res.json().catch(() => ({}));
      setResponsePayload(data);

    } catch (err: any) {
      setErrorMessage(err.message || "Failed to make HTTP exchange request.");
    } finally {
      setExecuting(false);
    }
  };

  // Compile Code snippet based on interactive options
  const compileCurlSnip = (): string => {
    if (!selectedTable) return "";
    const baseUrl = `${apiUrl}/api/rest/v1/${selectedTable.name}`;
    if (activeMethod === "GET") {
      return `curl -X GET "${baseUrl}${queryParam}" \\\n  -H "apikey: SUPABASE_KEY" \\\n  -H "Authorization: Bearer YOUR_JWT"`;
    }
    if (activeMethod === "POST") {
      const compactJson = postBodyJson.replace(/\n\s*/g, "");
      return `curl -X POST "${baseUrl}" \\\n  -H "Content-Type: application/json" \\\n  -d '${compactJson}'`;
    }
    return `curl -X DELETE "${baseUrl}${queryParam}"`;
  };

  const compileJsSnip = (): string => {
    if (!selectedTable) return "";
    if (activeMethod === "GET") {
      return `// Read records dynamically using Javascript Fetch
const response = await fetch("${apiUrl}/api/rest/v1/${selectedTable.name}${queryParam}", {
  headers: {
    "Authorization": "Bearer " + sessionToken
  }
});
const data = await response.json();
console.log(data);`;
    }
    if (activeMethod === "POST") {
      return `// Insert a row in '${selectedTable.name}'
const response = await fetch("${apiUrl}/api/rest/v1/${selectedTable.name}", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Authorization": "Bearer " + sessionToken
  },
  body: JSON.stringify(${postBodyJson.split("\n").join("\n  ")})
});
const inserted = await response.json();`;
    }
    return `// Erase file from table '${selectedTable.name}' with filters
const response = await fetch("${apiUrl}/api/rest/v1/${selectedTable.name}${queryParam}", {
  method: "DELETE",
  headers: {
    "Authorization": "Bearer " + sessionToken
  }
});`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="api-playground-root">
      {/* Parameters Panel Left */}
      <div className="lg:col-span-1 bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-5" id="playground-params-col">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">End-point Sandbox parameters</span>

        {/* Selected table dropdown */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-semibold text-slate-500 uppercase">Interactive Table</label>
          {tables.length === 0 ? (
            <p className="text-xs text-slate-400 py-1.5">Create a table first to query targets.</p>
          ) : (
            <select
              value={selectedTable?.name || ""}
              onChange={(e) => setSelectedTable(tables.find((t) => t.name === e.target.value) || null)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-200 bg-slate-50 font-mono"
            >
              {tables.map((t) => (
                <option key={t.name} value={t.name}>
                  {t.name}
                </option>
              ))}
            </select>
          )}
        </div>

        {/* Method selector buttons */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-semibold text-slate-500 uppercase block">HTTP Request Method</label>
          <div className="grid grid-cols-3 gap-1.5">
            {(["GET", "POST", "DELETE"] as const).map((method) => (
              <button
                key={method}
                onClick={() => {
                  setActiveMethod(method);
                  setResponseCode(null);
                  setResponsePayload(null);
                }}
                className={`p-2 rounded text-xs font-bold border transition-all cursor-pointer ${
                  activeMethod === method
                    ? method === "GET"
                      ? "bg-emerald-50 text-emerald-800 border-emerald-200 shadow-2xs"
                      : method === "POST"
                        ? "bg-indigo-50 text-indigo-800 border-indigo-200 shadow-2xs"
                        : "bg-rose-50 text-rose-800 border-rose-200 shadow-2xs"
                    : "bg-slate-50 text-slate-500 border-slate-200/60 hover:bg-slate-100"
                }`}
              >
                {method}
              </button>
            ))}
          </div>
        </div>

        {/* Query params filter or post Body text block */}
        {activeMethod === "GET" || activeMethod === "DELETE" ? (
          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-500 uppercase">Query Options / Filter URL params</label>
            <input
              type="text"
              placeholder="e.g. ?limit=5 or ?completed=eq.false"
              value={queryParam}
              onChange={(e) => setQueryParam(e.target.value)}
              className="w-full text-xs font-mono p-2.5 rounded-lg border border-slate-200 focus:outline-emerald-500 bg-slate-50 select-all"
            />
            <p className="text-[10px] text-slate-400 leading-tight">
              ErrorBase endpoints support standard PostgREST queries (e.g. <code className="font-mono text-indigo-500">?select=title&completed=eq.false</code>).
            </p>
          </div>
        ) : (
          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-500 uppercase">Request Body payload (JSON)</label>
            <textarea
              value={postBodyJson}
              onChange={(e) => setPostBodyJson(e.target.value)}
              className="w-full h-36 bg-slate-900 border border-slate-950 text-emerald-400 p-3 rounded-lg font-mono text-[11px] focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              spellCheck="false"
            />
          </div>
        )}

        {/* Trigger request */}
        <button
          onClick={executePlaygroundRequest}
          disabled={executing || !selectedTable}
          className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs p-3 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer disabled:bg-slate-300"
        >
          <Play className="h-3.5 w-3.5 fill-current" />
          {executing ? "Sending..." : "Execute Request"}
        </button>
      </div>

      {/* Code generation & output display Right */}
      <div className="lg:col-span-2 flex flex-col gap-4" id="playground-code-col">
        {/* Code Generator Sheets */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4 flex-1">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Generated Integration Codes</span>

          {/* curl */}
          <div className="space-y-1" id="snippet-curl-card">
            <div className="flex justify-between items-center text-[10px] uppercase font-bold text-slate-500">
              <span className="flex items-center gap-1">
                <Terminal className="h-3.5 w-3.5 text-slate-400" /> Shell / cURL Client
              </span>
              <button
                onClick={() => copyToClipboard(compileCurlSnip(), "curl")}
                className="text-emerald-600 hover:text-emerald-700 font-bold flex items-center gap-1 transition-all"
              >
                {copiedLabel === "curl" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                {copiedLabel === "curl" ? "Copied" : "Copy"}
              </button>
            </div>
            <pre className="p-3 bg-slate-900 border border-slate-950 text-[10px] font-mono text-emerald-300 rounded-lg overflow-x-auto select-all">
              {compileCurlSnip()}
            </pre>
          </div>

          {/* js fetch */}
          <div className="space-y-1" id="snippet-js-card">
            <div className="flex justify-between items-center text-[10px] uppercase font-bold text-slate-500">
              <span className="flex items-center gap-1">
                <FileJson className="h-3.5 w-3.5 text-slate-400" /> Javascript Client
              </span>
              <button
                onClick={() => copyToClipboard(compileJsSnip(), "js")}
                className="text-emerald-600 hover:text-emerald-700 font-bold flex items-center gap-1 transition-all"
              >
                {copiedLabel === "js" ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                {copiedLabel === "js" ? "Copied" : "Copy"}
              </button>
            </div>
            <pre className="p-3 bg-slate-900 border border-slate-950 text-[10px] font-mono text-emerald-300 rounded-lg overflow-x-auto select-all">
              {compileJsSnip()}
            </pre>
          </div>
        </div>

        {/* Live Response Panel */}
        {(responseCode !== null || errorMessage) && (
          <div className="bg-slate-900 text-white border border-slate-950 rounded-xl p-5 shadow-lg space-y-3" id="playground-response-panel animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Live API Response</span>
              {responseCode && (
                <span className={`text-[10px] font-bold px-2.2 py-0.5 rounded-full ${
                  responseCode >= 200 && responseCode < 300 ? "bg-emerald-950 text-emerald-400 border border-emerald-800" : "bg-rose-950 text-rose-400 border border-rose-800"
                }`}>
                  HTTP CODE {responseCode}
                </span>
              )}
            </div>

            {errorMessage ? (
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-rose-950/80 border border-rose-900 text-rose-300 text-xs font-mono leading-snug">
                <AlertCircle className="h-4.5 w-4.5 text-rose-400 flex-shrink-0 mt-0.5" />
                <span>Error exchange: {errorMessage}</span>
              </div>
            ) : (
              <div className="space-y-3 font-mono text-[10px]" id="response-content">
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-slate-400 overflow-x-auto max-h-[80px]" id="res-headers">
                  <pre>{responseHeaders}</pre>
                </div>
                <div className="bg-slate-950 p-3 rounded border border-slate-800 text-emerald-400 overflow-y-auto max-h-[140px]" id="res-body">
                  <pre>{JSON.stringify(responsePayload, null, 2)}</pre>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
