import React, { useState } from "react";
import { AuthUser } from "../types.ts";
import { Users, Plus, ShieldCheck, Mail, Calendar, Key, ShieldX, HelpCircle } from "lucide-react";

interface AuthManagerProps {
  users: AuthUser[];
  onRefresh: () => void;
  apiUrl: string;
}

export default function AuthManagerTab({ users, onRefresh, apiUrl }: AuthManagerProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!email || !password) {
      setErrorMsg("Both email and password are required credentials.");
      return;
    }

    try {
      const res = await fetch(`${apiUrl}/auth/v1/signup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, full_name: fullName }),
      });

      if (res.ok) {
        setSuccessMsg(`User registration succeeded! New member '${email}' registered successfully.`);
        setEmail("");
        setPassword("");
        setFullName("");
        setIsRegistering(false);
        onRefresh();
      } else {
        const err = await res.json();
        setErrorMsg(err.error || "Failed to register credentials.");
      }
    } catch (err) {
      setErrorMsg("Server is currently unreachable.");
    }
  };

  const triggerPasswordRecovery = async (userEmail: string) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await fetch(`${apiUrl}/auth/v1/recover`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: userEmail }),
      });

      if (res.ok) {
        const d = await res.json();
        setSuccessMsg(d.message || "Password recovery notification dispatched.");
      } else {
        setErrorMsg("Failed to dispatch password recovery notifications.");
      }
    } catch (err) {
      setErrorMsg("Server error trying to dispatch emails.");
    }
  };

  return (
    <div className="space-y-6" id="auth-manager-tab-root">
      {/* Notifications */}
      {errorMsg && (
        <div className="p-3 bg-rose-50 text-rose-800 text-xs rounded-lg border border-rose-200 flex justify-between items-center" id="auth-err">
          <span>{errorMsg}</span>
          <button onClick={() => setErrorMsg(null)} className="hover:text-rose-950 font-bold">&times;</button>
        </div>
      )}
      {successMsg && (
        <div className="p-3 bg-emerald-50 text-emerald-800 text-xs rounded-lg border border-emerald-200 flex justify-between items-center" id="auth-succ">
          <span>{successMsg}</span>
          <button onClick={() => setSuccessMsg(null)} className="hover:text-emerald-950 font-bold">&times;</button>
        </div>
      )}

      {/* Main card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-6" id="auth-manager-main-card">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Users className="h-5 w-5 text-emerald-500" />
              User Authentication Directory (GoTrue simulation)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Edit, browse, and register developer user credentials securely using standard JWT sessions.</p>
          </div>

          <button
            onClick={() => setIsRegistering(true)}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-lg flex items-center gap-1 cursor-pointer shadow-xs"
          >
            <Plus className="h-4 w-4" /> Add User Account
          </button>
        </div>

        {/* Users list spreadsheet */}
        <div className="overflow-x-auto border border-slate-100 rounded-lg" id="auth-users-scroller">
          <table className="w-full text-xs text-left border-collapse" id="auth-users-table">
            <thead className="bg-slate-50 border-b border-slate-100 select-none font-mono font-medium text-slate-500 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3">User UUID</th>
                <th className="px-4 py-3">Email Address</th>
                <th className="px-4 py-3">Registered Date</th>
                <th className="px-4 py-3">Verification Badge</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {users.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-400">
                    No active user registers indexed. Click Addition to sign-up accounts.
                  </td>
                </tr>
              ) : (
                users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/40 select-all">
                    <td className="px-4 py-3 text-slate-400 truncate max-w-[120px]" title={u.id}>
                      {u.id}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-700 flex items-center gap-1.5">
                      <Mail className="h-3.5 w-3.5 text-slate-400" />
                      {u.email}
                    </td>
                    <td className="px-4 py-3 text-slate-500 font-sans">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="h-3.5 w-3.5 text-slate-300" />
                        {new Date(u.created_at).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-100 px-2 py-0.5 rounded-full font-bold">
                        <ShieldCheck className="h-3 w-3" /> VERIFIED
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        onClick={() => triggerPasswordRecovery(u.email)}
                        className="text-xs bg-slate-50 hover:bg-slate-100 border border-slate-200 px-2.5 py-1 rounded text-slate-600 transition-colors font-sans font-semibold cursor-pointer"
                        title="Send recovery credentials simulation payload"
                      >
                        Reset Password
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Registration popup modal */}
      {isRegistering && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 animate-fade-in" id="add-user-modal">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xl max-w-sm w-full p-6 space-y-4 animate-scale-up">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <span className="text-sm font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-tighter">
                <Users className="h-4 w-4 text-emerald-500" /> Sign-up New Dev User
              </span>
              <button onClick={() => setIsRegistering(false)} className="text-slate-400 hover:text-slate-600 text-lg font-bold">&times;</button>
            </div>

            <form onSubmit={handleRegister} className="space-y-4 text-xs font-sans">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase pb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="name@example.dev"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-slate-200 p-2.5 rounded-lg bg-slate-50 font-mono text-xs focus:outline-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase pb-1">Full Name</label>
                <input
                  type="text"
                  placeholder="Demo Member"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full border border-slate-200 p-2.5 rounded-lg bg-slate-50 font-sans text-xs focus:outline-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 uppercase pb-1">Master Password</label>
                <input
                  type="password"
                  placeholder="Min 6 characters..."
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full border border-slate-200 p-2.5 rounded-lg bg-slate-50 font-mono text-xs focus:outline-emerald-500"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-slate-900 border border-slate-950 p-2.5 rounded-lg text-white font-semibold text-xs mt-4 hover:bg-slate-800 cursor-pointer text-center"
              >
                Register Credentials
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
