import React, { useState } from "react";
import { DatabaseStats } from "../types.ts";
import { Server, Database, Key, ShieldCheck, Activity, Terminal, Check, Copy } from "lucide-react";

interface OverviewProps {
  stats: DatabaseStats;
  apiUrl: string;
}

export default function OverviewTab({ stats, apiUrl }: OverviewProps) {
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const connectionDetails = [
    { label: "Project URL", value: apiUrl, isSecret: false },
    { label: "Anon Public API Key", value: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.errorbase-anon-key-level-1", isSecret: true },
    { label: "Service Role Secret Key", value: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.errorbase-service-role-admin", isSecret: true },
    { label: "POSTGRES DB HOST", value: "0.0.0.0 (errorbase_pool)", isSecret: false },
    { label: "POSTGRES Port", value: "3000", isSecret: false },
    { label: "DB NAME", value: "errorbase", isSecret: false },
    { label: "DB USER", value: "postgres", isSecret: false },
  ];

  return (
    <div className="space-y-6" id="overview-tab-root">
      {/* Welcome Banner */}
      <div className="bg-radial from-slate-900 to-slate-950 text-white p-6 rounded-xl shadow-md border border-slate-800 relative overflow-hidden" id="welcome-banner">
        <div className="relative z-10">
          <h2 className="text-2xl font-semibold tracking-tight">Project Command Center</h2>
          <p className="text-slate-400 mt-1 max-w-2xl text-sm">
            Welcome to <span className="text-emerald-400 font-semibold">ErrorBase</span>, your instant, full-stack Postgres-like sandbox. Manage custom databases, autogenerate dynamic REST APIs, track live subscriptions, and upload files.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              REST API Engine: Online
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              WebSocket Subscriptions: Active
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              Storage: Enabled
            </span>
          </div>
        </div>
        <div className="absolute top-0 right-0 h-full w-1/3 bg-linear-to-l from-slate-900/10 to-transparent pointer-events-none" />
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4" id="overview-metrics-grid">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4" id="stats-card-tables">
          <div className="p-3 rounded-lg bg-emerald-50 text-emerald-600">
            <Database className="h-6 w-6" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Active Tables</p>
            <h3 className="text-2xl font-bold text-slate-800 mt-0.5">{stats.tablesCount}</h3>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4" id="stats-card-users">
          <div className="p-3 rounded-lg bg-indigo-50 text-indigo-600">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Auth Users</p>
            <h3 className="text-2xl font-bold text-slate-800 mt-0.5">{stats.usersCount}</h3>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4" id="stats-card-storage">
          <div className="p-3 rounded-lg bg-amber-50 text-amber-600">
            <Server className="h-6 w-6" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Buckets</p>
            <h3 className="text-2xl font-bold text-slate-800 mt-0.5">{stats.bucketsCount}</h3>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4" id="stats-card-latency">
          <div className="p-3 rounded-lg bg-rose-50 text-rose-600">
            <Activity className="h-6 w-6" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Avg API Latency</p>
            <h3 className="text-2xl font-bold text-slate-800 mt-0.5">{stats.avgLatencyMs.toFixed(1)} ms</h3>
          </div>
        </div>
      </div>

      {/* Connection & Credentials */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="overview-credentials-block">
        {/* Connection Sheet */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 lg:col-span-2 shadow-xs space-y-4" id="connection-details-card">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-lg font-semibold text-slate-800">Connection Parameters</h3>
            <p className="text-xs text-slate-500">Secure parameters to connect client scripts and external libraries.</p>
          </div>
          <div className="space-y-3">
            {connectionDetails.map((item, idx) => (
              <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between py-1.5 border-b border-slate-50 last:border-0 gap-2">
                <span className="text-xs font-medium text-slate-500">{item.label}</span>
                <div className="flex items-center gap-2 max-w-full sm:max-w-[70%]">
                  <code className="text-xs bg-slate-50 text-slate-600 px-2.5 py-1 rounded border border-slate-200/80 truncate font-mono select-all">
                    {item.value}
                  </code>
                  <button
                    onClick={() => copyToClipboard(item.value, item.label)}
                    className="p-1 hover:bg-slate-100 rounded text-slate-400 hover:text-slate-600 transition-colors"
                    title="Copy info"
                  >
                    {copiedText === item.label ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Client Initialization Guide */}
        <div className="bg-slate-900 text-white p-6 rounded-xl shadow-md border border-slate-800 space-y-4 flex flex-col justify-between" id="client-init-card">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 font-semibold mb-2">
              <Terminal className="h-4.5 w-4.5" />
              <span className="text-sm font-mono tracking-wider">errorbase-js SDK</span>
            </div>
            <h4 className="text-base font-semibold">Integrate directly in your code</h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Call automatic endpoints instantly. Initialize the standard ErrorBase SDK in your browser or server clients:
            </p>
            <pre className="text-[11px] font-mono bg-slate-950 p-3 rounded mt-4 border border-slate-800 overflow-x-auto text-emerald-300">
{`import { createClient } from "errorbase-js";

// Initialize client session
const eb = createClient(
  "${apiUrl}",
  "eyJhbGciOiJIUzI1NiIs..."
);`}
            </pre>
          </div>
          <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Current Server Status:</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
              Operational
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
