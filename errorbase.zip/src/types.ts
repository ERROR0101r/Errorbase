export interface Column {
  name: string;
  type: "text" | "number" | "boolean" | "timestamp";
  is_primary: boolean;
  default_value?: any;
}

export type RlsPolicy = "public_all" | "public_read_auth_write" | "owner_only" | "private";

export interface TableSchema {
  name: string;
  rls_enabled: boolean;
  policy: RlsPolicy;
  columns: Column[];
}

export interface AuthUser {
  id: string;
  email: string;
  created_at: string;
}

export interface StorageBucket {
  name: string;
  is_public: boolean;
  created_at: string;
}

export interface StorageFile {
  bucket: string;
  path: string;
  size: number;
  mimeType: string;
  updatedAt: string;
}

export interface ApiLog {
  id: string;
  timestamp: string;
  method: string;
  path: string;
  status: number;
  ip: string;
  durationMs: number;
}

export interface DatabaseStats {
  tablesCount: number;
  usersCount: number;
  bucketsCount: number;
  filesCount: number;
  totalRequests: number;
  avgLatencyMs: number;
  uptimeSeconds: number;
}
